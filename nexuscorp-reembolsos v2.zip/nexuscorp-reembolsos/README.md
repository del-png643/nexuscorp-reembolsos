# NexusCorp — Plataforma de Gestão de Reembolsos Corporativos

API REST em **Python (FastAPI + SQLAlchemy)** para registrar, analisar e pagar reembolsos de despesas, com
controle de acesso por perfil (colaborador, gestor e financeiro), fluxo de aprovação e histórico de decisões.

A documentação técnica completa está em [`docs/DOCUMENTACAO.md`](docs/DOCUMENTACAO.md).

## Requisitos
- Python 3.10 ou superior

## Como executar

```bash
# 1. ambiente virtual e dependências
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2. configuração (opcional, mas recomendado)
cp .env.example .env               # Windows: copy .env.example .env
#   gere uma chave:  python -c "import secrets; print(secrets.token_urlsafe(48))"
#   e cole em SECRET_KEY no arquivo .env

# 3. dados de demonstração (departamentos e usuários)
python -m app.seed

# 4. iniciar a API
uvicorn app.main:app --reload
```

- Documentação interativa (Swagger): http://127.0.0.1:8000/docs
- Banco: SQLite no arquivo `nexuscorp.db` (persistente). Para PostgreSQL, defina `DATABASE_URL` no `.env`
  (ex.: `postgresql://usuario:senha@host:5432/nexuscorp`) e instale `pip install psycopg2-binary`.

## Usuários de demonstração (senha de todos: `Senha@123`)

| E-mail | Perfil | Departamento |
|---|---|---|
| ana@nexuscorp.com.br | colaborador | Comercial |
| bruno@nexuscorp.com.br | colaborador | Tecnologia |
| patricia@nexuscorp.com.br | gestor | Comercial |
| carlos@nexuscorp.com.br | gestor | Tecnologia |
| fernanda@nexuscorp.com.br | financeiro | Financeiro |

Gestores e financeiro só existem por cadastro administrativo (`app/seed.py`); a API não permite criar nem
promover usuários a esses perfis.

## Como testar no Swagger
1. Abra `/docs`, execute `POST /auth/login` com e-mail e senha e copie o `access_token`.
2. Clique em **Authorize** (cadeado), cole o token no campo *Value* e confirme.
3. Use as rotas. Para trocar de usuário, clique em Authorize → Logout e entre com outro token.

## Testes e evidências

```bash
pytest -v                                   # 49 testes de API + 18 unitários (banco de teste separado)
pytest -v > docs/evidencias/pytest.txt      # guarda a saída como evidência

# com a API rodando e o seed executado:
python scripts/demo_cenarios.py                              # relatório dos 8 cenários no terminal
python scripts/demo_cenarios.py > docs/evidencias/demo_cenarios.txt
```

Os testes usam o banco `test_nexuscorp.db` (recriado a cada teste) e **não alteram** o `nexuscorp.db` da aplicação.

| Cenário | Teste que comprova |
|---|---|
| 01 Acesso indevido | `test_cen01_acesso_indevido_ana_consulta_solicitacao_do_bruno` |
| 02 Gestor de outro departamento | `test_cen02_gestor_de_outro_departamento_nao_aprova` |
| 03 Credenciais incorretas | `test_cen03_senha_incorreta_nao_revela_informacoes` |
| 04 Alteração de permissões | `test_cen04_cadastro_nao_aceita_definir_perfil`, `test_cen04_colaborador_nao_consegue_elevar_o_proprio_perfil` |
| 05 Aprovação fora da sequência | `test_cen05_financeiro_nao_aprova_antes_do_gestor` |
| 06 Manipulação de solicitação | `test_cen06_manipulacao_de_valor_apos_o_envio` |
| 07 Consulta com filtros | `test_cen07_gestor_consulta_pendentes_so_do_proprio_departamento` |
| 08 Histórico financeiro | `test_cen08_historico_completo_do_fluxo` |

## Estrutura

```
app/
  main.py          aplicação FastAPI, tratamento de erros, documentação
  config.py        variáveis de ambiente
  database.py      conexão e sessão do banco
  models.py        tabelas (Departamento, Usuario, Solicitacao, HistoricoAnalise, TokenRevogado)
  schemas.py       contratos de entrada e saída (validações)
  regras.py        perfis, situações e fluxo de aprovação (regras puras)
  security.py      hash de senha (scrypt) e tokens JWT
  deps.py          autenticação e controle de acesso por perfil
  servicos.py      consultas e regras de visibilidade
  seed.py          dados de demonstração
  routers/         auth, usuarios (+ departamentos), solicitacoes, analise (gestor e financeiro)
tests/             testes unitários e de API
scripts/           demonstração dos cenários contra a API em execução
docs/              documentação técnica e evidências
```
