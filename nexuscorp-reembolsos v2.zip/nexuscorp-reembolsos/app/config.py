"""Configurações da aplicação, lidas de variáveis de ambiente (ou do arquivo .env)."""
import logging
import os
import secrets

from dotenv import load_dotenv

load_dotenv()

# Banco de dados. Padrão: SQLite local (arquivo nexuscorp.db).
# Para PostgreSQL: postgresql://usuario:senha@host:5432/banco
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./nexuscorp.db")

# Chave usada para assinar os tokens de acesso (JWT). Nunca deve ir para o repositório.
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    SECRET_KEY = secrets.token_urlsafe(48)
    logging.getLogger("uvicorn.error").warning(
        "SECRET_KEY não definida: foi gerada uma chave temporária. "
        "Os tokens deixam de valer quando a aplicação reiniciar. Defina SECRET_KEY no arquivo .env."
    )

JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))
