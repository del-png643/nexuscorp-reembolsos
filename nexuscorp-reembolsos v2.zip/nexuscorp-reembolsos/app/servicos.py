"""Consultas e regras de visibilidade compartilhadas pelas rotas de solicitação."""
from datetime import datetime, timezone
from typing import Optional

from fastapi import HTTPException, status
from sqlalchemy import and_, or_, select, update
from sqlalchemy.orm import Session, contains_eager

from .models import HistoricoAnalise, Solicitacao, Usuario
from .regras import (
    SITUACOES_VISIVEIS_FINANCEIRO,
    Acao,
    Categoria,
    Etapa,
    Perfil,
    Situacao,
    TransicaoInvalida,
    proxima_situacao,
)


def nao_encontrada() -> HTTPException:
    return HTTPException(status.HTTP_404_NOT_FOUND, "Solicitação não encontrada.")


def consulta_base():
    """SELECT de solicitações já unido ao solicitante (permite filtrar por departamento)."""
    return (
        select(Solicitacao)
        .join(Solicitacao.solicitante)
        .options(contains_eager(Solicitacao.solicitante))
    )


def aplicar_filtros(
    consulta,
    situacao: Optional[Situacao] = None,
    categoria: Optional[Categoria] = None,
    departamento_id: Optional[int] = None,
):
    if situacao is not None:
        consulta = consulta.where(Solicitacao.situacao == situacao)
    if categoria is not None:
        consulta = consulta.where(Solicitacao.categoria == categoria)
    if departamento_id is not None:
        consulta = consulta.where(Usuario.departamento_id == departamento_id)
    return consulta


def filtro_financeiro():
    """Solicitações que o financeiro pode ver: já passaram pelo gestor (inclui as que o próprio financeiro recusou)."""
    decidida_pelo_financeiro = (
        select(HistoricoAnalise.id)
        .where(
            HistoricoAnalise.solicitacao_id == Solicitacao.id,
            HistoricoAnalise.etapa == Etapa.FINANCEIRO,
        )
        .correlate(Solicitacao)
        .exists()
    )
    return or_(
        Solicitacao.situacao.in_(SITUACOES_VISIVEIS_FINANCEIRO),
        and_(Solicitacao.situacao == Situacao.RECUSADA, decidida_pelo_financeiro),
    )


def pode_visualizar(db: Session, usuario: Usuario, solicitacao: Solicitacao) -> bool:
    """RN02/RN03: dono; gestor do mesmo departamento; financeiro (somente após o gestor). Rascunho é só do dono."""
    if solicitacao.solicitante_id == usuario.id:
        return True
    if solicitacao.situacao == Situacao.RASCUNHO:
        return False
    if usuario.perfil == Perfil.GESTOR:
        return solicitacao.solicitante.departamento_id == usuario.departamento_id
    if usuario.perfil == Perfil.FINANCEIRO:
        visivel = db.scalar(
            select(Solicitacao.id).where(Solicitacao.id == solicitacao.id, filtro_financeiro())
        )
        return visivel is not None
    return False


def obter_visivel(db: Session, usuario: Usuario, solicitacao_id: int) -> Solicitacao:
    """Devolve a solicitação ou 404. O 404 é igual para 'não existe' e 'não é sua' (não revela existência)."""
    solicitacao = db.get(Solicitacao, solicitacao_id)
    if solicitacao is None or not pode_visualizar(db, usuario, solicitacao):
        raise nao_encontrada()
    return solicitacao


def obter_do_solicitante(db: Session, usuario: Usuario, solicitacao_id: int) -> Solicitacao:
    """Para operações exclusivas do dono (editar, excluir, enviar). Outro usuário recebe 404."""
    solicitacao = db.get(Solicitacao, solicitacao_id)
    if solicitacao is None or solicitacao.solicitante_id != usuario.id:
        raise nao_encontrada()
    return solicitacao


def aplicar_transicao(
    db: Session,
    solicitacao: Solicitacao,
    acao: Acao,
    historico: Optional[HistoricoAnalise] = None,
) -> Solicitacao:
    """Aplica uma transição do fluxo de aprovação e grava o histórico na mesma transação.

    O UPDATE só acontece se a situação ainda for a que foi lida; se outra operação mudou a
    solicitação nesse meio tempo, nada é gravado (evita decisões duplicadas ou fora de ordem).
    """
    nova = proxima_situacao(solicitacao.situacao, acao)  # levanta TransicaoInvalida (409)
    resultado = db.execute(
        update(Solicitacao)
        .where(Solicitacao.id == solicitacao.id, Solicitacao.situacao == solicitacao.situacao)
        .values(situacao=nova, atualizado_em=datetime.now(timezone.utc))
        .execution_options(synchronize_session=False)
    )
    if resultado.rowcount != 1:
        db.rollback()
        raise TransicaoInvalida(
            "A solicitação foi alterada por outra operação. Consulte a situação atual e tente novamente."
        )
    if historico is not None:
        db.add(historico)
    db.commit()
    db.refresh(solicitacao)
    return solicitacao
