"""Ponto de entrada da API: uvicorn app.main:app --reload"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, RedirectResponse

from . import models  # noqa: F401  (registra as tabelas no metadata)
from .database import Base, engine
from .regras import TransicaoInvalida
from .routers import analise, auth, solicitacoes, usuarios

DESCRICAO = """
API de **gestão de reembolsos corporativos** da NexusCorp.

**Como testar no Swagger:** faça login em `POST /auth/login`, copie o `access_token` e clique em
**Authorize** (campo *Value*), ou use diretamente o botão Authorize com e-mail (em *username*) e senha.

**Códigos de resposta:** `401` não identificado · `403` sem permissão · `404` inexistente ou fora do escopo ·
`409` violação de regra de negócio (situação incompatível, duplicidade) · `422` dados inválidos.
"""


@asynccontextmanager
async def lifespan(_app: FastAPI):
    Base.metadata.create_all(bind=engine)  # cria as tabelas na primeira execução
    yield


app = FastAPI(
    title="NexusCorp - Gestão de Reembolsos",
    version="1.0.0",
    description=DESCRICAO,
    lifespan=lifespan,
)

app.include_router(auth.router)
app.include_router(usuarios.router)
app.include_router(usuarios.router_departamentos)
app.include_router(solicitacoes.router)
app.include_router(analise.gestor_router)
app.include_router(analise.financeiro_router)


@app.exception_handler(TransicaoInvalida)
async def transicao_invalida_handler(_request: Request, exc: TransicaoInvalida):
    """Transições fora do fluxo de aprovação viram 409 (violação de regra de negócio)."""
    return JSONResponse(status_code=409, content={"detail": str(exc)})


@app.exception_handler(RequestValidationError)
async def validacao_handler(_request: Request, exc: RequestValidationError):
    """422 sem devolver o valor enviado (evita ecoar senhas e outros dados sensíveis, RN13)."""
    erros = [
        {
            "campo": ".".join(str(parte) for parte in erro["loc"] if parte != "body"),
            "mensagem": erro["msg"],
            "tipo": erro["type"],
        }
        for erro in exc.errors()
    ]
    return JSONResponse(status_code=422, content={"detail": erros})


@app.get("/", include_in_schema=False)
def raiz():
    return RedirectResponse(url="/docs")


@app.get("/saude", tags=["Sistema"], summary="Verifica se a API está no ar")
def saude():
    return {"status": "ok"}
