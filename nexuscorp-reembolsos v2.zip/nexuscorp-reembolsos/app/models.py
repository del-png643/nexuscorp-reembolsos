"""Modelo de dados: Departamento, Usuario, Solicitacao, HistoricoAnalise (+ TokenRevogado para o logout)."""
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Optional

from sqlalchemy import (
    CheckConstraint,
    Date,
    DateTime,
    ForeignKey,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy import Boolean
from sqlalchemy import Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base
from .regras import Categoria, Decisao, Etapa, Perfil, Situacao


def _agora() -> datetime:
    return datetime.now(timezone.utc)


def _enum(classe):
    """Guarda o valor do enum ('rascunho') como texto, em qualquer banco."""
    return SAEnum(
        classe,
        native_enum=False,
        length=30,
        values_callable=lambda membros: [m.value for m in membros],
        validate_strings=True,
    )


class Departamento(Base):
    __tablename__ = "departamentos"

    id: Mapped[int] = mapped_column(primary_key=True)
    nome: Mapped[str] = mapped_column(String(100), unique=True)

    usuarios: Mapped[list["Usuario"]] = relationship(back_populates="departamento")


class Usuario(Base):
    __tablename__ = "usuarios"

    id: Mapped[int] = mapped_column(primary_key=True)
    nome: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    senha_hash: Mapped[str] = mapped_column(String(255))  # RN13: nunca a senha em texto
    perfil: Mapped[Perfil] = mapped_column(_enum(Perfil), default=Perfil.COLABORADOR)
    departamento_id: Mapped[int] = mapped_column(ForeignKey("departamentos.id"))
    ativo: Mapped[bool] = mapped_column(Boolean, default=True)
    criado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_agora)

    departamento: Mapped[Departamento] = relationship(back_populates="usuarios")
    solicitacoes: Mapped[list["Solicitacao"]] = relationship(back_populates="solicitante")


class Solicitacao(Base):
    __tablename__ = "solicitacoes"
    __table_args__ = (
        # RN05: o mesmo colaborador não pode reutilizar a referência de comprovante.
        UniqueConstraint("solicitante_id", "comprovante_ref", name="uq_solicitante_comprovante"),
        # RN04: o banco também recusa valores iguais ou inferiores a zero.
        CheckConstraint("valor > 0", name="ck_valor_positivo"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    solicitante_id: Mapped[int] = mapped_column(ForeignKey("usuarios.id"), index=True)
    categoria: Mapped[Categoria] = mapped_column(_enum(Categoria))
    valor: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    data_despesa: Mapped[date] = mapped_column(Date)
    justificativa: Mapped[str] = mapped_column(Text)
    comprovante_ref: Mapped[str] = mapped_column(String(100))
    situacao: Mapped[Situacao] = mapped_column(
        _enum(Situacao), default=Situacao.RASCUNHO, index=True
    )
    criado_em: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_agora)
    atualizado_em: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_agora, onupdate=_agora
    )

    solicitante: Mapped[Usuario] = relationship(back_populates="solicitacoes")
    historico: Mapped[list["HistoricoAnalise"]] = relationship(
        back_populates="solicitacao",
        order_by="HistoricoAnalise.id",
        cascade="all, delete-orphan",
    )

    @property
    def solicitante_nome(self) -> str:
        return self.solicitante.nome

    @property
    def departamento_id(self) -> int:
        return self.solicitante.departamento_id


class HistoricoAnalise(Base):
    __tablename__ = "historico_analises"

    id: Mapped[int] = mapped_column(primary_key=True)
    solicitacao_id: Mapped[int] = mapped_column(ForeignKey("solicitacoes.id"), index=True)
    responsavel_id: Mapped[int] = mapped_column(ForeignKey("usuarios.id"))
    etapa: Mapped[Etapa] = mapped_column(_enum(Etapa))
    decisao: Mapped[Decisao] = mapped_column(_enum(Decisao))
    data: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_agora)
    observacao: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    solicitacao: Mapped[Solicitacao] = relationship(back_populates="historico")
    responsavel: Mapped[Usuario] = relationship()

    @property
    def responsavel_nome(self) -> str:
        return self.responsavel.nome

    @property
    def responsavel_perfil(self) -> Perfil:
        return self.responsavel.perfil


class TokenRevogado(Base):
    """Tokens encerrados no logout. Impedem novas operações mesmo antes da expiração (RN14)."""

    __tablename__ = "tokens_revogados"

    jti: Mapped[str] = mapped_column(String(64), primary_key=True)
    expira_em: Mapped[datetime] = mapped_column(DateTime(timezone=True))
