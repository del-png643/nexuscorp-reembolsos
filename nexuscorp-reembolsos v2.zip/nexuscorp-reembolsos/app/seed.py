"""Dados de demonstração: departamentos e usuários (execute: python -m app.seed).

Gestores e financeiro só existem porque são criados aqui (administração). A API não
permite criar nem promover usuários a esses perfis (RN15).
"""
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .database import Base, SessionLocal, engine
from .models import Departamento, Usuario
from .regras import Perfil
from .security import gerar_hash_senha

SENHA_DEMO = "Senha@123"

DEPARTAMENTOS = ["Comercial", "Tecnologia", "Financeiro", "Recursos Humanos"]

USUARIOS = [
    # (nome, e-mail, perfil, departamento)
    ("Ana Souza", "ana@nexuscorp.com.br", Perfil.COLABORADOR, "Comercial"),
    ("Bruno Lima", "bruno@nexuscorp.com.br", Perfil.COLABORADOR, "Tecnologia"),
    ("Patrícia Alves", "patricia@nexuscorp.com.br", Perfil.GESTOR, "Comercial"),
    ("Carlos Menezes", "carlos@nexuscorp.com.br", Perfil.GESTOR, "Tecnologia"),
    ("Fernanda Rocha", "fernanda@nexuscorp.com.br", Perfil.FINANCEIRO, "Financeiro"),
]


def popular_dados_demo(db: Session) -> None:
    """Idempotente: não faz nada se já houver departamentos cadastrados."""
    if db.scalar(select(func.count(Departamento.id))):
        return
    por_nome = {nome: Departamento(nome=nome) for nome in DEPARTAMENTOS}
    db.add_all(por_nome.values())
    db.flush()
    senha_hash = gerar_hash_senha(SENHA_DEMO)
    for nome, email, perfil, departamento in USUARIOS:
        db.add(
            Usuario(
                nome=nome,
                email=email,
                senha_hash=senha_hash,
                perfil=perfil,
                departamento_id=por_nome[departamento].id,
            )
        )
    db.commit()


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as sessao:
        popular_dados_demo(sessao)
    print("Dados de demonstração prontos. Usuários (senha de todos: %s):" % SENHA_DEMO)
    for nome, email, perfil, departamento in USUARIOS:
        print(f"  {email:<28} {perfil.value:<11} {departamento:<11} {nome}")
