"""Dependências de autenticação e autorização usadas pelas rotas."""
from typing import Annotated, Optional

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from .database import get_db
from .models import TokenRevogado, Usuario
from .regras import Perfil
from .security import decodificar_token

DB = Annotated[Session, Depends(get_db)]

# auto_error=False: a mensagem de "não autenticado" é montada aqui, de forma única.
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/token", auto_error=False)

# Respostas de erro documentadas no Swagger.
RESP_401 = {401: {"description": "Não identificado: token ausente, inválido, expirado ou encerrado."}}
RESP_403 = {403: {"description": "Identificado, mas sem permissão para esta operação."}}
RESP_404 = {404: {"description": "Recurso inexistente ou fora do escopo do usuário."}}
RESP_409 = {409: {"description": "Violação de regra de negócio (situação incompatível, duplicidade)."}}
RESP_422 = {422: {"description": "Dados inválidos."}}


def _nao_autenticado() -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Não autenticado: informe um token de acesso válido.",
        headers={"WWW-Authenticate": "Bearer"},
    )


def get_token_payload(token: Annotated[Optional[str], Depends(oauth2_scheme)], db: DB) -> dict:
    """RN01 e RN14: valida assinatura, expiração e se o token não foi encerrado no logout."""
    if not token:
        raise _nao_autenticado()
    try:
        payload = decodificar_token(token)
    except jwt.PyJWTError:
        raise _nao_autenticado()
    if db.get(TokenRevogado, payload["jti"]) is not None:
        raise _nao_autenticado()
    return payload


def get_usuario_atual(payload: Annotated[dict, Depends(get_token_payload)], db: DB) -> Usuario:
    try:
        usuario_id = int(payload["sub"])
    except (KeyError, ValueError):
        raise _nao_autenticado()
    usuario = db.get(Usuario, usuario_id)
    if usuario is None or not usuario.ativo:
        raise _nao_autenticado()
    return usuario


UsuarioAtual = Annotated[Usuario, Depends(get_usuario_atual)]


def exige_perfil(*perfis: Perfil):
    """Cria uma dependência que só deixa passar usuários com um dos perfis informados."""

    def _verifica(usuario: UsuarioAtual) -> Usuario:
        if usuario.perfil not in perfis:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Seu perfil não tem permissão para esta operação.",
            )
        return usuario

    return _verifica


Gestor = Annotated[Usuario, Depends(exige_perfil(Perfil.GESTOR))]
Financeiro = Annotated[Usuario, Depends(exige_perfil(Perfil.FINANCEIRO))]
