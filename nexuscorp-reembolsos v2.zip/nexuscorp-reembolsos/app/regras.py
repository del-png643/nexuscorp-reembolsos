"""Regras de domínio puras (sem banco e sem framework): perfis, situações e fluxo de aprovação."""
from enum import Enum


class Perfil(str, Enum):
    COLABORADOR = "colaborador"
    GESTOR = "gestor"
    FINANCEIRO = "financeiro"


class Categoria(str, Enum):
    ALIMENTACAO = "alimentacao"
    TRANSPORTE = "transporte"
    HOSPEDAGEM = "hospedagem"
    MATERIAIS = "materiais"


class Situacao(str, Enum):
    RASCUNHO = "rascunho"
    AGUARDANDO_GESTOR = "aguardando_gestor"
    AGUARDANDO_FINANCEIRO = "aguardando_financeiro"
    APROVADA = "aprovada"
    PAGA = "paga"
    RECUSADA = "recusada"


class Etapa(str, Enum):
    GESTOR = "gestor"
    FINANCEIRO = "financeiro"
    PAGAMENTO = "pagamento"


class Decisao(str, Enum):
    APROVADA = "aprovada"
    RECUSADA = "recusada"
    PAGA = "paga"


class Acao(str, Enum):
    ENVIAR = "enviar"
    GESTOR_APROVAR = "gestor_aprovar"
    GESTOR_RECUSAR = "gestor_recusar"
    FINANCEIRO_APROVAR = "financeiro_aprovar"
    FINANCEIRO_RECUSAR = "financeiro_recusar"
    REGISTRAR_PAGAMENTO = "registrar_pagamento"


class TransicaoInvalida(Exception):
    """A ação não é permitida para a situação atual da solicitação."""


# Fluxo de aprovação (seção 6 do enunciado): (situação atual, ação) -> próxima situação.
TRANSICOES = {
    (Situacao.RASCUNHO, Acao.ENVIAR): Situacao.AGUARDANDO_GESTOR,
    (Situacao.AGUARDANDO_GESTOR, Acao.GESTOR_APROVAR): Situacao.AGUARDANDO_FINANCEIRO,
    (Situacao.AGUARDANDO_GESTOR, Acao.GESTOR_RECUSAR): Situacao.RECUSADA,
    (Situacao.AGUARDANDO_FINANCEIRO, Acao.FINANCEIRO_APROVAR): Situacao.APROVADA,
    (Situacao.AGUARDANDO_FINANCEIRO, Acao.FINANCEIRO_RECUSAR): Situacao.RECUSADA,
    (Situacao.APROVADA, Acao.REGISTRAR_PAGAMENTO): Situacao.PAGA,
}

SITUACOES_ENCERRADAS = (Situacao.PAGA, Situacao.RECUSADA)

# Situações que o financeiro enxerga: solicitações que já passaram pelo gestor.
SITUACOES_VISIVEIS_FINANCEIRO = (
    Situacao.AGUARDANDO_FINANCEIRO,
    Situacao.APROVADA,
    Situacao.PAGA,
)


def proxima_situacao(atual: Situacao, acao: Acao) -> Situacao:
    """Devolve a próxima situação ou levanta TransicaoInvalida (RN07, RN08, RN10)."""
    try:
        return TRANSICOES[(atual, acao)]
    except KeyError:
        raise TransicaoInvalida(
            f"A ação '{acao.value}' não é permitida para uma solicitação na situação '{atual.value}'."
        ) from None


def pode_editar(situacao: Situacao) -> bool:
    """RN07: só rascunhos podem ser alterados."""
    return situacao == Situacao.RASCUNHO


def pode_excluir(situacao: Situacao) -> bool:
    """Só solicitações ainda não enviadas para aprovação podem ser excluídas."""
    return situacao == Situacao.RASCUNHO
