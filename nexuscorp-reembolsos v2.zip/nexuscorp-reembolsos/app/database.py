"""Conexão com o banco relacional (SQLAlchemy)."""
import warnings
from typing import Iterator

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from . import config

_eh_sqlite = config.DATABASE_URL.startswith("sqlite")

if _eh_sqlite:
    # O SQLite guarda decimais como número e avisa sobre isso; o valor é reconvertido com 2 casas.
    warnings.filterwarnings("ignore", message=".*does \\*not\\* support Decimal.*")

engine = create_engine(
    config.DATABASE_URL,
    connect_args={"check_same_thread": False} if _eh_sqlite else {},
    pool_pre_ping=True,
)

if _eh_sqlite:

    @event.listens_for(engine, "connect")
    def _ativar_chaves_estrangeiras(dbapi_conexao, _registro):
        # O SQLite não aplica chaves estrangeiras por padrão; aqui elas são ativadas.
        cursor = dbapi_conexao.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()


SessionLocal = sessionmaker(bind=engine, autoflush=False)


class Base(DeclarativeBase):
    pass


def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
