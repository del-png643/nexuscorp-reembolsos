"""Senhas (hash com salt) e tokens de acesso (JWT)."""
import base64
import hashlib
import hmac
import os
import uuid
from datetime import datetime, timedelta, timezone

import jwt

from . import config

# Parâmetros do scrypt (função de derivação de chave resistente a força bruta).
_N, _R, _P = 2**14, 8, 1


def _b64(dados: bytes) -> str:
    return base64.b64encode(dados).decode("ascii")


def gerar_hash_senha(senha: str) -> str:
    """RN13: a senha nunca é guardada de forma legível; guarda-se salt + hash."""
    salt = os.urandom(16)
    derivada = hashlib.scrypt(senha.encode("utf-8"), salt=salt, n=_N, r=_R, p=_P, dklen=32)
    return f"scrypt${_N}${_R}${_P}${_b64(salt)}${_b64(derivada)}"


def verificar_senha(senha: str, hash_armazenado: str) -> bool:
    try:
        algoritmo, n, r, p, salt_b64, hash_b64 = hash_armazenado.split("$")
        if algoritmo != "scrypt":
            return False
        salt = base64.b64decode(salt_b64)
        esperado = base64.b64decode(hash_b64)
        derivada = hashlib.scrypt(
            senha.encode("utf-8"), salt=salt, n=int(n), r=int(r), p=int(p), dklen=len(esperado)
        )
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(derivada, esperado)


# Hash usado quando o e-mail não existe, para que o tempo de resposta do login
# seja parecido nos dois casos (evita descobrir quais e-mails estão cadastrados).
HASH_FICTICIO = gerar_hash_senha("senha-ficticia-para-igualar-tempo")


def criar_token(usuario_id: int) -> tuple[str, int]:
    """Cria um JWT com identificador único (jti) e expiração. Devolve (token, segundos de validade)."""
    agora = datetime.now(timezone.utc)
    expira = agora + timedelta(minutes=config.ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {
        "sub": str(usuario_id),
        "jti": uuid.uuid4().hex,
        "iat": agora,
        "exp": expira,
    }
    token = jwt.encode(payload, config.SECRET_KEY, algorithm=config.JWT_ALGORITHM)
    return token, config.ACCESS_TOKEN_EXPIRE_MINUTES * 60


def decodificar_token(token: str) -> dict:
    """Valida assinatura e expiração. Levanta jwt.PyJWTError se o token não for válido (RN14)."""
    return jwt.decode(
        token,
        config.SECRET_KEY,
        algorithms=[config.JWT_ALGORITHM],
        options={"require": ["exp", "sub", "jti"]},
    )
