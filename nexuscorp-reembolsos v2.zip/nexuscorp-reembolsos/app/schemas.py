"""Contratos de entrada e saída da API (Pydantic)."""
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    PlainSerializer,
    StringConstraints,
    field_validator,
    model_validator,
)

from .regras import Categoria, Decisao, Etapa, Perfil, Situacao

# Valor recebido: maior que zero (RN04), no máximo 2 casas decimais.
ValorEntrada = Annotated[Decimal, Field(gt=0, max_digits=12, decimal_places=2)]
# Valor devolvido: número no JSON (ex.: 180.0).
ValorSaida = Annotated[Decimal, PlainSerializer(lambda v: float(v), return_type=float, when_used="json")]


class EntradaBase(BaseModel):
    """Base dos contratos de entrada: campos desconhecidos são recusados (evita 'perfil', 'situacao' etc.)."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


# ----------------------------------------------------------------- Autenticação
class LoginIn(BaseModel):
    model_config = ConfigDict(extra="forbid")  # sem remoção de espaços: a senha vale exatamente como digitada

    email: str = Field(min_length=3, max_length=255, examples=["ana@nexuscorp.com.br"])
    senha: str = Field(min_length=1, max_length=128, examples=["Senha@123"])


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = Field(description="Validade do token, em segundos.")


# ------------------------------------------------------------ Departamento/Usuário
class DepartamentoOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str


class UsuarioCreate(BaseModel):
    """Cadastro público: sempre cria um COLABORADOR. Perfil não é aceito na entrada (RN15)."""

    model_config = ConfigDict(extra="forbid")  # sem remoção de espaços: a senha vale exatamente como digitada

    nome: Annotated[str, StringConstraints(strip_whitespace=True, min_length=3, max_length=120)] = Field(
        examples=["Maria Oliveira"]
    )
    email: EmailStr = Field(examples=["maria@nexuscorp.com.br"])
    senha: str = Field(min_length=8, max_length=128, examples=["Senha@123"])
    departamento_id: int = Field(ge=1)

    @field_validator("email")
    @classmethod
    def email_minusculo(cls, v: str) -> str:
        return v.lower()

    @field_validator("senha")
    @classmethod
    def senha_forte(cls, v: str) -> str:
        if not any(c.isalpha() for c in v) or not any(c.isdigit() for c in v):
            raise ValueError("A senha deve conter letras e números.")
        return v


class UsuarioUpdate(EntradaBase):
    """Atualização do próprio cadastro: apenas nome e e-mail. Perfil e departamento não são aceitos (RN15)."""

    nome: Optional[str] = Field(default=None, min_length=3, max_length=120)
    email: Optional[EmailStr] = None

    @field_validator("email")
    @classmethod
    def email_minusculo(cls, v):
        return v.lower() if v else v

    @model_validator(mode="after")
    def ao_menos_um_campo(self):
        if not self.model_fields_set:
            raise ValueError("Informe ao menos um campo para alterar.")
        for campo in self.model_fields_set:
            if getattr(self, campo) is None:
                raise ValueError(f"O campo '{campo}' não pode ser nulo.")
        return self


class UsuarioOut(BaseModel):
    """Nunca inclui senha nem hash (RN13)."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    nome: str
    email: str
    perfil: Perfil
    departamento: DepartamentoOut


# ------------------------------------------------------------------- Solicitação
def _data_nao_futura(v: Optional[date]) -> Optional[date]:
    # RN06: despesas com data futura não podem ser registradas.
    if v is not None and v > date.today():
        raise ValueError("A data da despesa não pode ser futura.")
    return v


class SolicitacaoCreate(EntradaBase):
    categoria: Categoria
    valor: ValorEntrada = Field(examples=[180.00])
    data_despesa: date = Field(examples=["2026-11-03"])
    justificativa: str = Field(min_length=5, max_length=1000, examples=["Almoço com cliente em visita técnica"])
    comprovante_ref: str = Field(min_length=3, max_length=100, examples=["NF-2026-000123"])

    @field_validator("data_despesa")
    @classmethod
    def valida_data(cls, v):
        return _data_nao_futura(v)


class SolicitacaoUpdate(EntradaBase):
    categoria: Optional[Categoria] = None
    valor: Optional[ValorEntrada] = None
    data_despesa: Optional[date] = None
    justificativa: Optional[str] = Field(default=None, min_length=5, max_length=1000)
    comprovante_ref: Optional[str] = Field(default=None, min_length=3, max_length=100)

    @field_validator("data_despesa")
    @classmethod
    def valida_data(cls, v):
        return _data_nao_futura(v)

    @model_validator(mode="after")
    def ao_menos_um_campo(self):
        if not self.model_fields_set:
            raise ValueError("Informe ao menos um campo para alterar.")
        for campo in self.model_fields_set:
            if getattr(self, campo) is None:
                raise ValueError(f"O campo '{campo}' não pode ser nulo.")
        return self


class SolicitacaoOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    solicitante_id: int
    solicitante_nome: str
    departamento_id: int
    categoria: Categoria
    valor: ValorSaida
    data_despesa: date
    justificativa: str
    comprovante_ref: str
    situacao: Situacao
    criado_em: datetime
    atualizado_em: datetime


class AprovacaoIn(EntradaBase):
    observacao: Optional[str] = Field(default=None, max_length=500)


class RecusaIn(EntradaBase):
    """RN11: toda recusa exige justificativa."""

    justificativa: str = Field(min_length=5, max_length=500, examples=["Comprovante ilegível"])


class HistoricoOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    solicitacao_id: int
    responsavel_id: int
    responsavel_nome: str
    responsavel_perfil: Perfil
    etapa: Etapa
    decisao: Decisao
    data: datetime
    observacao: Optional[str] = None
