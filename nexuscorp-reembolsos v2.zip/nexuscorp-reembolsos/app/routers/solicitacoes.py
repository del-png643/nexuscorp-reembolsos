"""Operações do solicitante sobre as próprias solicitações (qualquer perfil pode registrar despesas)."""
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from ..deps import DB, RESP_401, RESP_404, RESP_409, RESP_422, UsuarioAtual
from ..models import Solicitacao
from ..regras import Acao, Categoria, Situacao, pode_editar, pode_excluir
from ..schemas import HistoricoOut, SolicitacaoCreate, SolicitacaoOut, SolicitacaoUpdate
from ..servicos import (
    aplicar_filtros,
    aplicar_transicao,
    consulta_base,
    obter_do_solicitante,
    obter_visivel,
)

router = APIRouter(prefix="/solicitacoes", tags=["Solicitações (minhas)"])


def _comprovante_duplicado(db, usuario_id: int, referencia: str, ignorar_id: Optional[int] = None) -> bool:
    """RN05: o mesmo colaborador não pode usar a mesma referência de comprovante duas vezes."""
    consulta = select(Solicitacao.id).where(
        Solicitacao.solicitante_id == usuario_id,
        func.lower(Solicitacao.comprovante_ref) == referencia.lower(),
    )
    if ignorar_id is not None:
        consulta = consulta.where(Solicitacao.id != ignorar_id)
    return db.scalar(consulta) is not None


def _erro_duplicidade() -> HTTPException:
    return HTTPException(
        status.HTTP_409_CONFLICT,
        "Já existe uma solicitação sua com esta referência de comprovante (RN05).",
    )


@router.post(
    "",
    response_model=SolicitacaoOut,
    status_code=status.HTTP_201_CREATED,
    summary="Registra uma solicitação (nasce como rascunho)",
    responses={**RESP_401, **RESP_409, **RESP_422},
)
def registrar(dados: SolicitacaoCreate, usuario: UsuarioAtual, db: DB):
    if _comprovante_duplicado(db, usuario.id, dados.comprovante_ref):
        raise _erro_duplicidade()
    solicitacao = Solicitacao(
        solicitante_id=usuario.id,  # sempre o usuário autenticado, nunca vem do corpo da requisição
        categoria=dados.categoria,
        valor=dados.valor,
        data_despesa=dados.data_despesa,
        justificativa=dados.justificativa,
        comprovante_ref=dados.comprovante_ref,
        situacao=Situacao.RASCUNHO,
    )
    db.add(solicitacao)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise _erro_duplicidade()
    db.refresh(solicitacao)
    return solicitacao


@router.get(
    "",
    response_model=list[SolicitacaoOut],
    summary="Lista as minhas solicitações (com filtros)",
    responses={**RESP_401, **RESP_422},
)
def listar_minhas(
    usuario: UsuarioAtual,
    db: DB,
    situacao: Optional[Situacao] = None,
    categoria: Optional[Categoria] = None,
    limite: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    consulta = consulta_base().where(Solicitacao.solicitante_id == usuario.id)
    consulta = aplicar_filtros(consulta, situacao, categoria)
    consulta = consulta.order_by(Solicitacao.id.desc()).limit(limite).offset(offset)
    return db.scalars(consulta).unique().all()


@router.get(
    "/{solicitacao_id}",
    response_model=SolicitacaoOut,
    summary="Detalhes de uma solicitação",
    description=(
        "Disponível para o solicitante, para o gestor do departamento do solicitante e para o "
        "financeiro (somente depois da aprovação do gestor). Nos demais casos a resposta é 404, "
        "igual à de uma solicitação inexistente (RN02)."
    ),
    responses={**RESP_401, **RESP_404},
)
def detalhar(solicitacao_id: int, usuario: UsuarioAtual, db: DB):
    return obter_visivel(db, usuario, solicitacao_id)


@router.patch(
    "/{solicitacao_id}",
    response_model=SolicitacaoOut,
    summary="Altera uma solicitação (somente rascunho)",
    responses={**RESP_401, **RESP_404, **RESP_409, **RESP_422},
)
def alterar(solicitacao_id: int, dados: SolicitacaoUpdate, usuario: UsuarioAtual, db: DB):
    solicitacao = obter_do_solicitante(db, usuario, solicitacao_id)
    if not pode_editar(solicitacao.situacao):
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"Solicitação na situação '{solicitacao.situacao.value}' não pode ser alterada: "
            "somente rascunhos (RN07).",
        )
    campos = dados.model_dump(exclude_unset=True)
    referencia = campos.get("comprovante_ref")
    if referencia is not None and _comprovante_duplicado(db, usuario.id, referencia, solicitacao.id):
        raise _erro_duplicidade()
    for campo, valor in campos.items():
        setattr(solicitacao, campo, valor)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise _erro_duplicidade()
    db.refresh(solicitacao)
    return solicitacao


@router.delete(
    "/{solicitacao_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Exclui uma solicitação ainda não enviada",
    responses={**RESP_401, **RESP_404, **RESP_409},
)
def excluir(solicitacao_id: int, usuario: UsuarioAtual, db: DB):
    solicitacao = obter_do_solicitante(db, usuario, solicitacao_id)
    if not pode_excluir(solicitacao.situacao):
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"Solicitação na situação '{solicitacao.situacao.value}' não pode ser excluída: "
            "somente rascunhos.",
        )
    db.delete(solicitacao)
    db.commit()


@router.post(
    "/{solicitacao_id}/enviar",
    response_model=SolicitacaoOut,
    summary="Encaminha o rascunho para análise do gestor",
    responses={**RESP_401, **RESP_404, **RESP_409},
)
def enviar(solicitacao_id: int, usuario: UsuarioAtual, db: DB):
    solicitacao = obter_do_solicitante(db, usuario, solicitacao_id)
    return aplicar_transicao(db, solicitacao, Acao.ENVIAR)


@router.get(
    "/{solicitacao_id}/historico",
    response_model=list[HistoricoOut],
    summary="Histórico de decisões (responsável, etapa, decisão, data e observação)",
    responses={**RESP_401, **RESP_404},
)
def historico(solicitacao_id: int, usuario: UsuarioAtual, db: DB):
    solicitacao = obter_visivel(db, usuario, solicitacao_id)
    return solicitacao.historico
