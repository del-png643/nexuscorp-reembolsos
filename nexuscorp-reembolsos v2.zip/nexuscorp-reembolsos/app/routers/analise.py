"""Análise de solicitações: gestor (etapa 1) e financeiro (etapa 2 e pagamento)."""
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, status

from ..deps import DB, RESP_401, RESP_403, RESP_404, RESP_409, RESP_422, Financeiro, Gestor
from ..models import HistoricoAnalise, Solicitacao, Usuario
from ..regras import Acao, Categoria, Decisao, Etapa, Situacao
from ..schemas import AprovacaoIn, RecusaIn, SolicitacaoOut
from ..servicos import (
    aplicar_filtros,
    aplicar_transicao,
    consulta_base,
    filtro_financeiro,
    nao_encontrada,
)

gestor_router = APIRouter(prefix="/gestor", tags=["Gestor"])
financeiro_router = APIRouter(prefix="/financeiro", tags=["Financeiro"])


# ----------------------------------------------------------------- verificações comuns
def _carregar(db, usuario: Usuario, solicitacao_id: int) -> Solicitacao:
    """Rascunho é privado do solicitante: para os demais, é como se não existisse."""
    solicitacao = db.get(Solicitacao, solicitacao_id)
    if solicitacao is None or (
        solicitacao.situacao == Situacao.RASCUNHO and solicitacao.solicitante_id != usuario.id
    ):
        raise nao_encontrada()
    return solicitacao


def _nao_e_o_proprio(usuario: Usuario, solicitacao: Solicitacao) -> None:
    """RN09: ninguém analisa uma solicitação de sua própria autoria, qualquer que seja o perfil."""
    if solicitacao.solicitante_id == usuario.id:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Você não pode analisar uma solicitação de sua própria autoria (RN09).",
        )


def _mesmo_departamento(gestor: Usuario, solicitacao: Solicitacao) -> None:
    """RN03: o gestor só analisa solicitações do seu departamento."""
    if solicitacao.solicitante.departamento_id != gestor.departamento_id:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Esta solicitação pertence a outro departamento (RN03).",
        )


def _historico(solicitacao: Solicitacao, usuario: Usuario, etapa: Etapa, decisao: Decisao, observacao):
    """RN12: responsável, etapa, decisão e observação; o momento é gravado automaticamente."""
    return HistoricoAnalise(
        solicitacao_id=solicitacao.id,
        responsavel_id=usuario.id,
        etapa=etapa,
        decisao=decisao,
        observacao=observacao,
    )


# ------------------------------------------------------------------------------ GESTOR
@gestor_router.get(
    "/solicitacoes",
    response_model=list[SolicitacaoOut],
    summary="Solicitações do departamento do gestor (com filtros)",
    description=(
        "Sempre limitado ao departamento do gestor autenticado. Rascunhos não aparecem. "
        "Para ver apenas as pendentes: `situacao=aguardando_gestor`."
    ),
    responses={**RESP_401, **RESP_403, **RESP_422},
)
def gestor_listar(
    gestor: Gestor,
    db: DB,
    situacao: Optional[Situacao] = None,
    categoria: Optional[Categoria] = None,
    departamento_id: Optional[int] = Query(None, description="Só é aceito o próprio departamento."),
    limite: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    if departamento_id is not None and departamento_id != gestor.departamento_id:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Gestores só consultam solicitações do próprio departamento (RN03).",
        )
    consulta = consulta_base().where(
        Usuario.departamento_id == gestor.departamento_id,
        Solicitacao.situacao != Situacao.RASCUNHO,
    )
    consulta = aplicar_filtros(consulta, situacao, categoria)
    consulta = consulta.order_by(Solicitacao.id.desc()).limit(limite).offset(offset)
    return db.scalars(consulta).unique().all()


@gestor_router.post(
    "/solicitacoes/{solicitacao_id}/aprovar",
    response_model=SolicitacaoOut,
    summary="Gestor aprova: segue para o financeiro",
    responses={**RESP_401, **RESP_403, **RESP_404, **RESP_409},
)
def gestor_aprovar(solicitacao_id: int, gestor: Gestor, db: DB, dados: Optional[AprovacaoIn] = None):
    solicitacao = _carregar(db, gestor, solicitacao_id)
    _mesmo_departamento(gestor, solicitacao)
    _nao_e_o_proprio(gestor, solicitacao)
    observacao = dados.observacao if dados else None
    historico = _historico(solicitacao, gestor, Etapa.GESTOR, Decisao.APROVADA, observacao)
    return aplicar_transicao(db, solicitacao, Acao.GESTOR_APROVAR, historico)


@gestor_router.post(
    "/solicitacoes/{solicitacao_id}/recusar",
    response_model=SolicitacaoOut,
    summary="Gestor recusa (justificativa obrigatória)",
    responses={**RESP_401, **RESP_403, **RESP_404, **RESP_409, **RESP_422},
)
def gestor_recusar(solicitacao_id: int, dados: RecusaIn, gestor: Gestor, db: DB):
    solicitacao = _carregar(db, gestor, solicitacao_id)
    _mesmo_departamento(gestor, solicitacao)
    _nao_e_o_proprio(gestor, solicitacao)
    historico = _historico(solicitacao, gestor, Etapa.GESTOR, Decisao.RECUSADA, dados.justificativa)
    return aplicar_transicao(db, solicitacao, Acao.GESTOR_RECUSAR, historico)


# -------------------------------------------------------------------------- FINANCEIRO
@financeiro_router.get(
    "/solicitacoes",
    response_model=list[SolicitacaoOut],
    summary="Solicitações encaminhadas pelos gestores (com filtros)",
    description="Só aparecem solicitações que já passaram pela aprovação do gestor.",
    responses={**RESP_401, **RESP_403, **RESP_422},
)
def financeiro_listar(
    _financeiro: Financeiro,
    db: DB,
    situacao: Optional[Situacao] = None,
    categoria: Optional[Categoria] = None,
    departamento_id: Optional[int] = None,
    limite: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    consulta = consulta_base().where(filtro_financeiro())
    consulta = aplicar_filtros(consulta, situacao, categoria, departamento_id)
    consulta = consulta.order_by(Solicitacao.id.desc()).limit(limite).offset(offset)
    return db.scalars(consulta).unique().all()


@financeiro_router.post(
    "/solicitacoes/{solicitacao_id}/aprovar",
    response_model=SolicitacaoOut,
    summary="Financeiro aprova (só depois do gestor)",
    responses={**RESP_401, **RESP_403, **RESP_404, **RESP_409},
)
def financeiro_aprovar(solicitacao_id: int, financeiro: Financeiro, db: DB, dados: Optional[AprovacaoIn] = None):
    solicitacao = _carregar(db, financeiro, solicitacao_id)
    _nao_e_o_proprio(financeiro, solicitacao)
    observacao = dados.observacao if dados else None
    historico = _historico(solicitacao, financeiro, Etapa.FINANCEIRO, Decisao.APROVADA, observacao)
    return aplicar_transicao(db, solicitacao, Acao.FINANCEIRO_APROVAR, historico)


@financeiro_router.post(
    "/solicitacoes/{solicitacao_id}/recusar",
    response_model=SolicitacaoOut,
    summary="Financeiro recusa (justificativa obrigatória)",
    responses={**RESP_401, **RESP_403, **RESP_404, **RESP_409, **RESP_422},
)
def financeiro_recusar(solicitacao_id: int, dados: RecusaIn, financeiro: Financeiro, db: DB):
    solicitacao = _carregar(db, financeiro, solicitacao_id)
    _nao_e_o_proprio(financeiro, solicitacao)
    historico = _historico(solicitacao, financeiro, Etapa.FINANCEIRO, Decisao.RECUSADA, dados.justificativa)
    return aplicar_transicao(db, solicitacao, Acao.FINANCEIRO_RECUSAR, historico)


@financeiro_router.post(
    "/solicitacoes/{solicitacao_id}/pagamento",
    response_model=SolicitacaoOut,
    summary="Registra o pagamento (só de solicitações aprovadas pelo financeiro)",
    responses={**RESP_401, **RESP_403, **RESP_404, **RESP_409},
)
def financeiro_registrar_pagamento(
    solicitacao_id: int, financeiro: Financeiro, db: DB, dados: Optional[AprovacaoIn] = None
):
    solicitacao = _carregar(db, financeiro, solicitacao_id)
    _nao_e_o_proprio(financeiro, solicitacao)
    observacao = dados.observacao if dados else None
    historico = _historico(solicitacao, financeiro, Etapa.PAGAMENTO, Decisao.PAGA, observacao)
    return aplicar_transicao(db, solicitacao, Acao.REGISTRAR_PAGAMENTO, historico)
