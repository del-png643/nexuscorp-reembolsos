from datetime import datetime, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import delete, select

from ..deps import DB, RESP_401, RESP_422, UsuarioAtual, get_token_payload
from ..models import TokenRevogado, Usuario
from ..schemas import LoginIn, TokenOut
from ..security import HASH_FICTICIO, criar_token, verificar_senha

router = APIRouter(prefix="/auth", tags=["Autenticação"])


def _autenticar(db, email: str, senha: str) -> Usuario:
    """Mesma resposta para e-mail inexistente e senha errada (Cenário 03): não revela qual dado falhou."""
    usuario = db.scalar(select(Usuario).where(Usuario.email == email.strip().lower()))
    hash_armazenado = usuario.senha_hash if usuario is not None else HASH_FICTICIO
    senha_confere = verificar_senha(senha, hash_armazenado)
    if usuario is None or not senha_confere or not usuario.ativo:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais inválidas.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return usuario


def _emitir_token(usuario: Usuario) -> TokenOut:
    token, validade = criar_token(usuario.id)
    return TokenOut(access_token=token, expires_in=validade)


@router.post(
    "/login",
    response_model=TokenOut,
    summary="Autentica o usuário e devolve o token de acesso",
    responses={**RESP_401, **RESP_422},
)
def login(dados: LoginIn, db: DB):
    return _emitir_token(_autenticar(db, dados.email, dados.senha))


@router.post(
    "/token",
    response_model=TokenOut,
    summary="Login por formulário (usado pelo botão Authorize do Swagger)",
    description="Informe o e-mail no campo `username`.",
    responses={**RESP_401},
)
def login_formulario(form: Annotated[OAuth2PasswordRequestForm, Depends()], db: DB):
    return _emitir_token(_autenticar(db, form.username, form.password))


@router.post(
    "/logout",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Encerra a sessão: o token deixa de ser aceito imediatamente",
    responses={**RESP_401},
)
def logout(_usuario: UsuarioAtual, payload: Annotated[dict, Depends(get_token_payload)], db: DB):
    agora = datetime.now(timezone.utc)
    # Limpa registros de tokens que já expiraram sozinhos.
    db.execute(delete(TokenRevogado).where(TokenRevogado.expira_em < agora))
    db.merge(
        TokenRevogado(
            jti=payload["jti"],
            expira_em=datetime.fromtimestamp(payload["exp"], tz=timezone.utc),
        )
    )
    db.commit()
