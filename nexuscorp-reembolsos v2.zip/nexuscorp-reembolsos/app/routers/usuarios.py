from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from ..deps import DB, RESP_401, RESP_409, RESP_422, UsuarioAtual
from ..models import Departamento, Usuario
from ..regras import Perfil
from ..schemas import DepartamentoOut, UsuarioCreate, UsuarioOut, UsuarioUpdate
from ..security import gerar_hash_senha

router = APIRouter(prefix="/usuarios", tags=["Usuários"])
router_departamentos = APIRouter(prefix="/departamentos", tags=["Departamentos"])


@router.post(
    "",
    response_model=UsuarioOut,
    status_code=status.HTTP_201_CREATED,
    summary="Cadastra um colaborador",
    description=(
        "Cria sempre um usuário com perfil **colaborador**. O perfil não pode ser informado "
        "(RN15); gestores e financeiro são cadastrados pela administração (`python -m app.seed`)."
    ),
    responses={**RESP_409, **RESP_422},
)
def cadastrar_colaborador(dados: UsuarioCreate, db: DB):
    if db.get(Departamento, dados.departamento_id) is None:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Departamento informado não existe.")
    if db.scalar(select(Usuario.id).where(Usuario.email == dados.email)) is not None:
        raise HTTPException(status.HTTP_409_CONFLICT, "E-mail já cadastrado.")
    usuario = Usuario(
        nome=dados.nome,
        email=dados.email,
        senha_hash=gerar_hash_senha(dados.senha),
        perfil=Perfil.COLABORADOR,
        departamento_id=dados.departamento_id,
    )
    db.add(usuario)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status.HTTP_409_CONFLICT, "E-mail já cadastrado.")
    db.refresh(usuario)
    return usuario


@router.get(
    "/me",
    response_model=UsuarioOut,
    summary="Dados do usuário autenticado",
    responses={**RESP_401},
)
def meus_dados(usuario: UsuarioAtual):
    return usuario


@router.patch(
    "/me",
    response_model=UsuarioOut,
    summary="Atualiza nome e/ou e-mail do próprio cadastro",
    description="Perfil e departamento não são aceitos nesta operação (RN15): o envio desses campos é recusado.",
    responses={**RESP_401, **RESP_409, **RESP_422},
)
def atualizar_meus_dados(dados: UsuarioUpdate, usuario: UsuarioAtual, db: DB):
    campos = dados.model_dump(exclude_unset=True)
    if "email" in campos:
        em_uso = db.scalar(
            select(Usuario.id).where(Usuario.email == campos["email"], Usuario.id != usuario.id)
        )
        if em_uso is not None:
            raise HTTPException(status.HTTP_409_CONFLICT, "E-mail já cadastrado.")
    for campo, valor in campos.items():
        setattr(usuario, campo, valor)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status.HTTP_409_CONFLICT, "E-mail já cadastrado.")
    db.refresh(usuario)
    return usuario


@router_departamentos.get(
    "",
    response_model=list[DepartamentoOut],
    summary="Lista os departamentos (necessário para o cadastro)",
)
def listar_departamentos(db: DB):
    return db.scalars(select(Departamento).order_by(Departamento.nome)).all()
