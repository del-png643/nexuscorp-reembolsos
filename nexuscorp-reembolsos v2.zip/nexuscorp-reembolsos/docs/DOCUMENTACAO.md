# Documentação técnica — Plataforma de Gestão de Reembolsos Corporativos (NexusCorp)

## 1. Descrição da solução

API REST desenvolvida em **Python** com **FastAPI**, persistência em banco relacional via **SQLAlchemy**
(SQLite por padrão; PostgreSQL por configuração) e autenticação por **token JWT**.

A API substitui as planilhas enviadas por e-mail e centraliza o ciclo do reembolso:

1. o colaborador registra a despesa (rascunho), pode editá-la ou excluí-la e a envia para análise;
2. o gestor do departamento aprova ou recusa;
3. o financeiro faz a análise final (aprova ou recusa) e registra o pagamento;
4. cada decisão fica gravada no histórico, com responsável, etapa, decisão, data e observação.

Os problemas apontados pela empresa são tratados assim: visibilidade restrita por perfil e por dono (RN02/RN03),
aprovação apenas pelo gestor do departamento (RN03), bloqueio de duplicidade por comprovante (RN05), histórico
imutável de decisões (RN12), bloqueio de alteração após o envio (RN07) e proteção de credenciais (RN13).

**Documentação interativa:** `/docs` (Swagger) e `/openapi.json`, geradas a partir dos contratos do código.

## 2. Modelo de dados

```mermaid
erDiagram
    DEPARTAMENTO ||--o{ USUARIO : "possui"
    USUARIO ||--o{ SOLICITACAO : "registra"
    SOLICITACAO ||--o{ HISTORICO_ANALISE : "tem"
    USUARIO ||--o{ HISTORICO_ANALISE : "decide"
```

| Tabela | Campos principais | Restrições |
|---|---|---|
| `departamentos` | id, nome | nome único |
| `usuarios` | id, nome, email, senha_hash, perfil, departamento_id, ativo, criado_em | e-mail único; FK departamento; perfil ∈ {colaborador, gestor, financeiro} |
| `solicitacoes` | id, solicitante_id, categoria, valor, data_despesa, justificativa, comprovante_ref, situacao, criado_em, atualizado_em | FK solicitante; **único (solicitante_id, comprovante_ref)** (RN05); **CHECK valor > 0** (RN04) |
| `historico_analises` | id, solicitacao_id, responsavel_id, etapa, decisao, data, observacao | FK solicitação e responsável |
| `tokens_revogados` | jti, expira_em | usado no logout (RN14) |

- **Categorias:** alimentacao, transporte, hospedagem, materiais.
- **Situações:** rascunho, aguardando_gestor, aguardando_financeiro, aprovada, paga, recusada.
- **Etapas do histórico:** gestor, financeiro, pagamento. **Decisões:** aprovada, recusada, paga.
- Cada colaborador pertence a um departamento e possui várias solicitações; cada solicitação possui vários
  registros de histórico, recuperáveis em ordem cronológica.

### Fluxo de aprovação

| Situação | Ação permitida | Quem | Próxima situação |
|---|---|---|---|
| rascunho | editar, excluir | solicitante | rascunho / (excluída) |
| rascunho | enviar | solicitante | aguardando_gestor |
| aguardando_gestor | aprovar | gestor do departamento | aguardando_financeiro |
| aguardando_gestor | recusar (com justificativa) | gestor do departamento | recusada |
| aguardando_financeiro | aprovar | financeiro | aprovada |
| aguardando_financeiro | recusar (com justificativa) | financeiro | recusada |
| aprovada | registrar pagamento | financeiro | paga |
| paga / recusada | nenhuma (encerrada) | — | — |

Qualquer outra combinação é recusada com **409**. A tabela de transições está em `app/regras.py` e a gravação
da nova situação só acontece se a situação ainda for a que foi lida (evita decisões duplicadas em requisições
simultâneas).

## 3. Contrato das principais operações

Todas as rotas, exceto as marcadas como públicas, exigem o cabeçalho `Authorization: Bearer <token>`.

| Método e rota | Acesso | Corpo de entrada | Sucesso | Erros possíveis |
|---|---|---|---|---|
| `POST /auth/login` | público | `{email, senha}` | 200 `{access_token, token_type, expires_in}` | 401, 422 |
| `POST /auth/token` | público | formulário (`username`=e-mail, `password`) — usado pelo Swagger | 200 | 401 |
| `POST /auth/logout` | autenticado | — | 204 | 401 |
| `POST /usuarios` | público | `{nome, email, senha, departamento_id}` | 201 usuário (sempre colaborador) | 409, 422 |
| `GET /usuarios/me` | autenticado | — | 200 usuário | 401 |
| `PATCH /usuarios/me` | autenticado | `{nome?, email?}` | 200 usuário | 401, 409, 422 |
| `GET /departamentos` | público | — | 200 lista | — |
| `POST /solicitacoes` | autenticado | `{categoria, valor, data_despesa, justificativa, comprovante_ref}` | 201 solicitação (rascunho) | 401, 409, 422 |
| `GET /solicitacoes?situacao=&categoria=&limite=&offset=` | autenticado | — | 200 minhas solicitações | 401, 422 |
| `GET /solicitacoes/{id}` | dono; gestor do departamento; financeiro (após o gestor) | — | 200 | 401, 404 |
| `PATCH /solicitacoes/{id}` | dono | campos opcionais da solicitação | 200 | 401, 404, 409, 422 |
| `DELETE /solicitacoes/{id}` | dono | — | 204 | 401, 404, 409 |
| `POST /solicitacoes/{id}/enviar` | dono | — | 200 (aguardando_gestor) | 401, 404, 409 |
| `GET /solicitacoes/{id}/historico` | igual ao detalhe | — | 200 lista de decisões | 401, 404 |
| `GET /gestor/solicitacoes?situacao=&categoria=&departamento_id=` | gestor | — | 200 (só do seu departamento) | 401, 403, 422 |
| `POST /gestor/solicitacoes/{id}/aprovar` | gestor do departamento | `{observacao?}` opcional | 200 | 401, 403, 404, 409 |
| `POST /gestor/solicitacoes/{id}/recusar` | gestor do departamento | `{justificativa}` obrigatória | 200 | 401, 403, 404, 409, 422 |
| `GET /financeiro/solicitacoes?situacao=&categoria=&departamento_id=` | financeiro | — | 200 (já aprovadas pelo gestor) | 401, 403, 422 |
| `POST /financeiro/solicitacoes/{id}/aprovar` | financeiro | `{observacao?}` opcional | 200 | 401, 403, 404, 409 |
| `POST /financeiro/solicitacoes/{id}/recusar` | financeiro | `{justificativa}` obrigatória | 200 | 401, 403, 404, 409, 422 |
| `POST /financeiro/solicitacoes/{id}/pagamento` | financeiro | `{observacao?}` opcional | 200 (paga) | 401, 403, 404, 409 |

### Exemplos

**Registrar solicitação** — `POST /solicitacoes`

```json
{
  "categoria": "alimentacao",
  "valor": 180.00,
  "data_despesa": "2026-11-03",
  "justificativa": "Almoço com cliente em visita técnica",
  "comprovante_ref": "NF-2026-000123"
}
```

Resposta `201`:

```json
{
  "id": 1,
  "solicitante_id": 1,
  "solicitante_nome": "Ana Souza",
  "departamento_id": 1,
  "categoria": "alimentacao",
  "valor": 180.0,
  "data_despesa": "2026-11-03",
  "justificativa": "Almoço com cliente em visita técnica",
  "comprovante_ref": "NF-2026-000123",
  "situacao": "rascunho",
  "criado_em": "2026-11-07T18:30:00",
  "atualizado_em": "2026-11-07T18:30:00"
}
```

**Histórico** — `GET /solicitacoes/1/historico`

```json
[
  {"id": 1, "solicitacao_id": 1, "responsavel_id": 3, "responsavel_nome": "Patrícia Alves",
   "responsavel_perfil": "gestor", "etapa": "gestor", "decisao": "aprovada",
   "data": "2026-11-07T18:35:00", "observacao": "Despesa regular"}
]
```

**Formato dos erros**

| Código | Quando | Corpo |
|---|---|---|
| 401 | sem token, token inválido/expirado/encerrado, credenciais incorretas | `{"detail": "Credenciais inválidas."}` |
| 403 | perfil sem permissão; gestor de outro departamento; autor tentando analisar a própria solicitação | `{"detail": "Esta solicitação pertence a outro departamento (RN03)."}` |
| 404 | não existe **ou** não pertence ao usuário (mesma resposta) | `{"detail": "Solicitação não encontrada."}` |
| 409 | regra de negócio: situação incompatível com a ação, comprovante duplicado, e-mail já cadastrado | `{"detail": "Solicitação na situação 'aguardando_gestor' não pode ser alterada: somente rascunhos (RN07)."}` |
| 422 | dados inválidos: campo ausente, valor ≤ 0, data futura, campo não permitido | `{"detail": [{"campo": "valor", "mensagem": "Input should be greater than 0", "tipo": "greater_than"}]}` |

O erro 422 **não devolve o valor enviado**, para não ecoar senhas e dados sensíveis.

## 4. Matriz de permissões

| Operação | Anônimo | Colaborador | Gestor | Financeiro |
|---|---|---|---|---|
| Login | ✔ | ✔ | ✔ | ✔ |
| Cadastro de colaborador / listar departamentos | ✔ | ✔ | ✔ | ✔ |
| Logout, consultar e atualizar o próprio cadastro | ✘ | ✔ | ✔ | ✔ |
| Registrar e listar **as próprias** solicitações | ✘ | ✔ | ✔ | ✔ |
| Editar / excluir / enviar solicitação própria (rascunho) | ✘ | ✔ | ✔ | ✔ |
| Ver detalhe e histórico de solicitação **de outro usuário** | ✘ | ✘ | só do **seu departamento** e já enviada | só se **já aprovada pelo gestor** (inclui as que ele recusou) |
| Listar solicitações para análise | ✘ | ✘ | `/gestor/...` (seu departamento) | `/financeiro/...` (todos os departamentos) |
| Aprovar / recusar na etapa do gestor | ✘ | ✘ | ✔ (seu departamento, **nunca a própria**) | ✘ |
| Aprovar / recusar na etapa financeira | ✘ | ✘ | ✘ | ✔ (**nunca a própria**) |
| Registrar pagamento | ✘ | ✘ | ✘ | ✔ (**nunca a própria**, só se aprovada) |
| Criar usuário gestor/financeiro ou alterar perfil/departamento | ✘ | ✘ | ✘ | ✘ (somente administração, por `app/seed.py`) |

Gestor e financeiro também podem registrar suas próprias despesas; por isso a segregação (RN09) é verificada
em todas as ações de análise, independentemente do perfil.

## 5. Regras de negócio implementadas

| Regra | Como é aplicada | Resposta |
|---|---|---|
| RN01 Identificação | `get_token_payload` (`app/deps.py`) exige token válido em toda rota restrita | 401 |
| RN02 Confidencialidade | consultas filtram por dono; `obter_visivel`/`obter_do_solicitante` (`app/servicos.py`) devolvem a mesma resposta para "não existe" e "não é sua" | 404 |
| RN03 Responsabilidade departamental | gestor só lista o próprio departamento; `_mesmo_departamento` bloqueia aprovar/recusar de outro departamento | 403 |
| RN04 Integridade dos valores | `valor > 0` no contrato (`schemas.py`) e `CHECK` no banco | 422 |
| RN05 Duplicidade | verificação por colaborador, sem diferenciar maiúsculas, mais restrição única no banco | 409 |
| RN06 Período da despesa | validador recusa data posterior a hoje | 422 |
| RN07 Alteração | só o dono edita/exclui, e só em rascunho (`pode_editar`, `pode_excluir`) | 409 |
| RN08 Aprovação | só existe a transição `aguardando_gestor → aguardando_financeiro` pelo gestor; o financeiro não age antes | 409 |
| RN09 Segregação | `_nao_e_o_proprio`: quem registrou não aprova, recusa nem paga a própria solicitação | 403 |
| RN10 Pagamento | pagamento só a partir de `aprovada` | 409 |
| RN11 Recusa | `justificativa` obrigatória (mín. 5 caracteres), gravada no histórico | 422 |
| RN12 Rastreabilidade | cada decisão grava responsável, etapa, decisão, data e observação **na mesma transação** da mudança de situação | — |
| RN13 Proteção de credenciais | senha com **scrypt + salt**; nenhum contrato de saída contém senha ou hash; erros 422 não ecoam o valor enviado | — |
| RN14 Controle de sessão | token com expiração (padrão 30 min); logout revoga o token na hora; usuário inativo é recusado | 401 |
| RN15 Proteção dos perfis | contratos de entrada recusam campos desconhecidos (`perfil`, `departamento_id`, `situacao`, `solicitante_id`…); cadastro público cria sempre colaborador | 422 |

Fluxo e transições: RN07, RN08 e RN10 decorrem da tabela de transições em `app/regras.py`; a seção 2 resume o fluxo.

### Cenários de homologação

| Cenário | Resultado da API |
|---|---|
| 01 Acesso indevido | Ana recebe **404** (igual a "solicitação inexistente"); nenhum dado do Bruno aparece |
| 02 Gestor de outro departamento | Patrícia recebe **403**; a solicitação não muda e não ganha histórico |
| 03 Credenciais incorretas | **401** `Credenciais inválidas.` — mesma resposta para senha errada e e-mail inexistente |
| 04 Alteração de permissões | **422** (campo não permitido); perfil e departamento permanecem; rotas do financeiro seguem em **403** |
| 05 Aprovação fora da sequência | **409**; a solicitação continua `aguardando_gestor` |
| 06 Manipulação de solicitação | **409**; o valor segue R$ 180,00 |
| 07 Consulta com filtros | **200** somente com o departamento do gestor; filtrar outro departamento dá **403** |
| 08 Histórico financeiro | 3 registros em ordem: gestor/aprovada → financeiro/aprovada → pagamento/paga, com o nome e o perfil de cada responsável |

## 6. Decisões de segurança

- **Autenticação por JWT assinado (HS256)** com `exp` e identificador único (`jti`). A chave vem da variável
  `SECRET_KEY` (não fica no código nem no repositório).
- **Logout efetivo:** o `jti` vai para a tabela `tokens_revogados`; o token deixa de valer imediatamente. A
  tabela é limpa de registros já expirados a cada logout.
- **Senhas:** scrypt com salt aleatório por usuário e comparação em tempo constante. No login, quando o e-mail
  não existe, é feita uma verificação fictícia e a mesma mensagem é devolvida, para não revelar quais e-mails existem.
- **Perfil vem do banco, nunca da requisição:** o perfil é lido do usuário autenticado; o solicitante de uma
  solicitação é sempre o usuário do token. Contratos com `extra="forbid"` recusam campos que tentem definir
  perfil, departamento, situação ou dono.
- **Perfis privilegiados fora da API:** gestores e financeiro só são criados pela administração (`app/seed.py`).
- **Não revelar existência:** acesso a solicitação de terceiros devolve 404 idêntico ao de ID inexistente (evita
  enumeração de identificadores). Já a tentativa de *agir* (aprovar) fora do escopo devolve 403, pois o usuário
  está identificado e a ação não é permitida para o seu papel.
- **Rascunhos são privados:** só o dono os enxerga; gestor e financeiro tratam um rascunho alheio como inexistente.
- **Respostas sem dados sensíveis:** contratos de saída explícitos; erros de validação sem o valor enviado.
- **Integridade em duas camadas:** regras validadas na aplicação e reforçadas no banco (restrição única, `CHECK`,
  chaves estrangeiras; no SQLite as chaves estrangeiras são ativadas na conexão).
- **Operações não autorizadas não gravam nada:** todas as verificações acontecem antes da escrita, e a mudança de
  situação + histórico são confirmados na mesma transação.

### Limitações conhecidas (versão 1)
- Não há limite de tentativas de login nem bloqueio temporário de conta.
- Não há renovação de token (refresh); ao expirar, o usuário entra novamente.
- As tabelas são criadas automaticamente (`create_all`); não há migrações versionadas (Alembic).
- Se um departamento tiver um único gestor, as solicitações dele próprio não têm quem aprove (consequência da RN09).
- O cadastro público permite escolher o departamento; isso não concede permissão extra, pois as permissões vêm do perfil.
