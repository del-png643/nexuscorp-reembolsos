"""Testes unitários das regras de domínio e da camada de segurança (não dependem de banco nem de HTTP)."""
import unittest
from datetime import datetime, timedelta, timezone
from unittest import mock

import jwt

from app import config, security
from app.regras import (
    Acao,
    Situacao,
    TransicaoInvalida,
    pode_editar,
    pode_excluir,
    proxima_situacao,
)


class FluxoDeAprovacaoTest(unittest.TestCase):
    """Seção 6 do enunciado: ciclo de vida da solicitação."""

    def test_caminho_feliz_ate_o_pagamento(self):
        s = Situacao.RASCUNHO
        s = proxima_situacao(s, Acao.ENVIAR)
        self.assertEqual(s, Situacao.AGUARDANDO_GESTOR)
        s = proxima_situacao(s, Acao.GESTOR_APROVAR)
        self.assertEqual(s, Situacao.AGUARDANDO_FINANCEIRO)
        s = proxima_situacao(s, Acao.FINANCEIRO_APROVAR)
        self.assertEqual(s, Situacao.APROVADA)
        s = proxima_situacao(s, Acao.REGISTRAR_PAGAMENTO)
        self.assertEqual(s, Situacao.PAGA)

    def test_recusa_pelo_gestor_e_pelo_financeiro(self):
        self.assertEqual(
            proxima_situacao(Situacao.AGUARDANDO_GESTOR, Acao.GESTOR_RECUSAR), Situacao.RECUSADA
        )
        self.assertEqual(
            proxima_situacao(Situacao.AGUARDANDO_FINANCEIRO, Acao.FINANCEIRO_RECUSAR),
            Situacao.RECUSADA,
        )

    def test_financeiro_nao_aprova_antes_do_gestor(self):  # Cenário 05 / RN08
        with self.assertRaises(TransicaoInvalida):
            proxima_situacao(Situacao.AGUARDANDO_GESTOR, Acao.FINANCEIRO_APROVAR)

    def test_pagamento_exige_aprovacao_financeira(self):  # RN10
        for situacao in (Situacao.RASCUNHO, Situacao.AGUARDANDO_GESTOR, Situacao.AGUARDANDO_FINANCEIRO):
            with self.assertRaises(TransicaoInvalida):
                proxima_situacao(situacao, Acao.REGISTRAR_PAGAMENTO)

    def test_situacoes_encerradas_nao_aceitam_nenhuma_acao(self):
        for situacao in (Situacao.PAGA, Situacao.RECUSADA):
            for acao in Acao:
                with self.assertRaises(TransicaoInvalida):
                    proxima_situacao(situacao, acao)

    def test_nao_e_possivel_pular_etapas(self):
        with self.assertRaises(TransicaoInvalida):
            proxima_situacao(Situacao.RASCUNHO, Acao.GESTOR_APROVAR)
        with self.assertRaises(TransicaoInvalida):
            proxima_situacao(Situacao.RASCUNHO, Acao.FINANCEIRO_APROVAR)
        with self.assertRaises(TransicaoInvalida):
            proxima_situacao(Situacao.AGUARDANDO_GESTOR, Acao.REGISTRAR_PAGAMENTO)

    def test_so_o_rascunho_pode_ser_editado_ou_excluido(self):  # RN07
        for situacao in Situacao:
            esperado = situacao == Situacao.RASCUNHO
            self.assertEqual(pode_editar(situacao), esperado, situacao)
            self.assertEqual(pode_excluir(situacao), esperado, situacao)

    def test_todo_destino_do_fluxo_e_uma_situacao_valida(self):
        from app.regras import TRANSICOES

        for destino in TRANSICOES.values():
            self.assertIsInstance(destino, Situacao)


class SenhasTest(unittest.TestCase):
    def test_hash_nao_guarda_a_senha_em_texto(self):  # RN13
        senha = "Senha@123"
        hash_gerado = security.gerar_hash_senha(senha)
        self.assertNotIn(senha, hash_gerado)
        self.assertTrue(hash_gerado.startswith("scrypt$"))

    def test_mesma_senha_gera_hashes_diferentes(self):
        self.assertNotEqual(
            security.gerar_hash_senha("Senha@123"), security.gerar_hash_senha("Senha@123")
        )

    def test_verifica_senha_correta_e_incorreta(self):  # Cenário 03
        hash_gerado = security.gerar_hash_senha("Senha@123")
        self.assertTrue(security.verificar_senha("Senha@123", hash_gerado))
        self.assertFalse(security.verificar_senha("senha@123", hash_gerado))
        self.assertFalse(security.verificar_senha("", hash_gerado))

    def test_hash_corrompido_nao_valida_nem_quebra(self):
        self.assertFalse(security.verificar_senha("x", "lixo"))
        self.assertFalse(security.verificar_senha("x", "md5$1$2$3$4$5"))


class TokensTest(unittest.TestCase):
    def test_token_valido_traz_usuario_e_identificador(self):
        token, validade = security.criar_token(42)
        payload = security.decodificar_token(token)
        self.assertEqual(payload["sub"], "42")
        self.assertTrue(payload["jti"])
        self.assertEqual(validade, config.ACCESS_TOKEN_EXPIRE_MINUTES * 60)

    def test_cada_token_tem_jti_proprio(self):
        jti1 = security.decodificar_token(security.criar_token(1)[0])["jti"]
        jti2 = security.decodificar_token(security.criar_token(1)[0])["jti"]
        self.assertNotEqual(jti1, jti2)

    def test_token_expirado_e_rejeitado(self):  # RN14
        with mock.patch.object(config, "ACCESS_TOKEN_EXPIRE_MINUTES", -1):
            token, _ = security.criar_token(1)
        with self.assertRaises(jwt.ExpiredSignatureError):
            security.decodificar_token(token)

    def test_token_adulterado_e_rejeitado(self):
        token, _ = security.criar_token(1)
        adulterado = token[:-3] + ("AAA" if not token.endswith("AAA") else "BBB")
        with self.assertRaises(jwt.PyJWTError):
            security.decodificar_token(adulterado)

    def test_token_assinado_com_outra_chave_e_rejeitado(self):
        agora = datetime.now(timezone.utc)
        falso = jwt.encode(
            {"sub": "1", "jti": "x", "exp": agora + timedelta(minutes=5)},
            "outra-chave",
            algorithm="HS256",
        )
        with self.assertRaises(jwt.PyJWTError):
            security.decodificar_token(falso)

    def test_token_sem_campos_obrigatorios_e_rejeitado(self):
        agora = datetime.now(timezone.utc)
        sem_jti = jwt.encode(
            {"sub": "1", "exp": agora + timedelta(minutes=5)},
            config.SECRET_KEY,
            algorithm=config.JWT_ALGORITHM,
        )
        with self.assertRaises(jwt.PyJWTError):
            security.decodificar_token(sem_jti)


if __name__ == "__main__":
    unittest.main()
