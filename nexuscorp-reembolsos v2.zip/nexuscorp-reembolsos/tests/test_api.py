"""Testes de API: cenários de homologação (seção 7) e regras de negócio (seção 5).

Cada teste informa o cenário (CEN) ou a regra (RN) que comprova.
Execute com:  pytest -v
"""
from datetime import date, timedelta

import pytest

from app import config


# ============================================================================ helpers
def enviar_ate_o_gestor(client, headers, solicitacao_id):
    r = client.post(f"/solicitacoes/{solicitacao_id}/enviar", headers=headers)
    assert r.status_code == 200, r.text
    return r.json()


def aprovar_pelo_gestor(client, headers, solicitacao_id):
    r = client.post(f"/gestor/solicitacoes/{solicitacao_id}/aprovar", headers=headers)
    assert r.status_code == 200, r.text
    return r.json()


# ============================================================ Autenticação (RN01, RN13, RN14)
def test_login_com_credenciais_corretas_devolve_token(client):
    r = client.post("/auth/login", json={"email": "ana@nexuscorp.com.br", "senha": "Senha@123"})
    assert r.status_code == 200
    corpo = r.json()
    assert corpo["token_type"] == "bearer"
    assert corpo["access_token"]
    assert corpo["expires_in"] == config.ACCESS_TOKEN_EXPIRE_MINUTES * 60


def test_rn01_rotas_restritas_exigem_identificacao(client):
    for metodo, rota in [
        ("get", "/solicitacoes"),
        ("get", "/solicitacoes/1"),
        ("get", "/usuarios/me"),
        ("get", "/gestor/solicitacoes"),
        ("get", "/financeiro/solicitacoes"),
        ("post", "/solicitacoes/1/enviar"),
    ]:
        r = getattr(client, metodo)(rota)
        assert r.status_code == 401, f"{metodo.upper()} {rota} -> {r.status_code}"


def test_rn01_token_invalido_e_rejeitado(client):
    r = client.get("/usuarios/me", headers={"Authorization": "Bearer isto.nao.e.um.token"})
    assert r.status_code == 401


def test_cen03_senha_incorreta_nao_revela_informacoes(client):
    errada = client.post("/auth/login", json={"email": "ana@nexuscorp.com.br", "senha": "SenhaErrada1"})
    inexistente = client.post("/auth/login", json={"email": "ninguem@nexuscorp.com.br", "senha": "SenhaErrada1"})
    assert errada.status_code == 401
    assert inexistente.status_code == 401
    # Mesma resposta nos dois casos: não dá para descobrir quais e-mails existem.
    assert errada.json() == inexistente.json() == {"detail": "Credenciais inválidas."}
    corpo = errada.text.lower()
    assert "senha@123" not in corpo and "hash" not in corpo and "scrypt" not in corpo
    assert "access_token" not in corpo


def test_rn13_respostas_nao_expoem_credenciais(client, entrar):
    h = entrar("ana")
    r = client.get("/usuarios/me", headers=h)
    assert r.status_code == 200
    texto = r.text.lower()
    assert "senha" not in texto and "hash" not in texto and "scrypt" not in texto
    assert set(r.json()) == {"id", "nome", "email", "perfil", "departamento"}


def test_rn13_erro_de_validacao_nao_ecoa_a_senha_enviada(client):
    r = client.post(
        "/usuarios",
        json={"nome": "Maria Teste", "email": "maria@nexuscorp.com.br", "senha": "curta", "departamento_id": 1},
    )
    assert r.status_code == 422
    assert "curta" not in r.text


def test_rn13_senha_nao_fica_legivel_no_banco(client):
    from sqlalchemy import select

    from app.database import SessionLocal
    from app.models import Usuario

    with SessionLocal() as db:
        for usuario in db.scalars(select(Usuario)).all():
            assert "Senha@123" not in usuario.senha_hash
            assert usuario.senha_hash.startswith("scrypt$")


def test_rn14_token_expirado_impede_novas_operacoes(client, monkeypatch):
    monkeypatch.setattr(config, "ACCESS_TOKEN_EXPIRE_MINUTES", -1)
    r = client.post("/auth/login", json={"email": "ana@nexuscorp.com.br", "senha": "Senha@123"})
    token = r.json()["access_token"]
    r = client.get("/usuarios/me", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 401


def test_rn14_logout_encerra_a_sessao(client, entrar):
    h = entrar("ana")
    assert client.get("/usuarios/me", headers=h).status_code == 200
    assert client.post("/auth/logout", headers=h).status_code == 204
    assert client.get("/usuarios/me", headers=h).status_code == 401
    assert client.get("/solicitacoes", headers=h).status_code == 401


# ================================================================ Cadastro e RN15 (CEN 04)
def test_cadastro_cria_sempre_um_colaborador(client):
    r = client.post(
        "/usuarios",
        json={"nome": "Maria Oliveira", "email": "Maria@NexusCorp.com.br", "senha": "Senha@123", "departamento_id": 1},
    )
    assert r.status_code == 201
    assert r.json()["perfil"] == "colaborador"
    assert r.json()["email"] == "maria@nexuscorp.com.br"


def test_cadastro_rejeita_email_duplicado(client):
    r = client.post(
        "/usuarios",
        json={"nome": "Outra Ana", "email": "ana@nexuscorp.com.br", "senha": "Senha@123", "departamento_id": 1},
    )
    assert r.status_code == 409


def test_cen04_cadastro_nao_aceita_definir_perfil(client):
    r = client.post(
        "/usuarios",
        json={
            "nome": "Mallory Teste",
            "email": "mallory@nexuscorp.com.br",
            "senha": "Senha@123",
            "departamento_id": 3,
            "perfil": "financeiro",
        },
    )
    assert r.status_code == 422
    # Nenhum usuário foi criado
    r = client.post("/auth/login", json={"email": "mallory@nexuscorp.com.br", "senha": "Senha@123"})
    assert r.status_code == 401


def test_cen04_colaborador_nao_consegue_elevar_o_proprio_perfil(client, entrar):
    h = entrar("ana")
    antes = client.get("/usuarios/me", headers=h).json()

    for tentativa in (
        {"perfil": "financeiro"},
        {"perfil": "gestor"},
        {"departamento_id": 3},
        {"departamento": {"id": 3, "nome": "Financeiro"}},
        {"nome": "Ana Souza", "perfil": "financeiro"},
    ):
        r = client.patch("/usuarios/me", json=tentativa, headers=h)
        assert r.status_code == 422, tentativa

    depois = client.get("/usuarios/me", headers=h).json()
    assert depois == antes
    assert depois["perfil"] == "colaborador"
    assert depois["departamento"]["nome"] == "Comercial"

    # E as permissões do financeiro continuam fora de alcance
    assert client.get("/financeiro/solicitacoes", headers=h).status_code == 403
    assert client.get("/gestor/solicitacoes", headers=h).status_code == 403


def test_atualizar_nome_e_email_do_proprio_cadastro(client, entrar):
    h = entrar("ana")
    r = client.patch("/usuarios/me", json={"nome": "Ana Souza Lima"}, headers=h)
    assert r.status_code == 200 and r.json()["nome"] == "Ana Souza Lima"
    r = client.patch("/usuarios/me", json={"email": "bruno@nexuscorp.com.br"}, headers=h)
    assert r.status_code == 409


# ============================================================== Solicitação: criação (RN04-06)
def test_registrar_solicitacao_nasce_como_rascunho_do_usuario_autenticado(client, entrar):
    h = entrar("ana")
    r = client.post(
        "/solicitacoes",
        json={
            "categoria": "transporte",
            "valor": 180.00,
            "data_despesa": "2026-11-03",
            "justificativa": "Corrida de táxi até o cliente",
            "comprovante_ref": "REC-0001",
        },
        headers=h,
    )
    assert r.status_code == 201
    corpo = r.json()
    assert corpo["situacao"] == "rascunho"
    assert corpo["valor"] == 180.0
    assert corpo["solicitante_nome"] == "Ana Souza"


def test_solicitante_nao_pode_ser_definido_pelo_corpo_da_requisicao(client, entrar):
    h = entrar("ana")
    r = client.post(
        "/solicitacoes",
        json={
            "categoria": "transporte",
            "valor": 50,
            "data_despesa": "2026-11-03",
            "justificativa": "Corrida de táxi",
            "comprovante_ref": "REC-0002",
            "solicitante_id": 2,
            "situacao": "paga",
        },
        headers=h,
    )
    assert r.status_code == 422


@pytest.mark.parametrize("valor", [0, -1, -180.5])
def test_rn04_valor_igual_ou_inferior_a_zero_e_recusado(client, entrar, valor):
    h = entrar("ana")
    r = client.post(
        "/solicitacoes",
        json={
            "categoria": "materiais",
            "valor": valor,
            "data_despesa": "2026-11-03",
            "justificativa": "Material de escritório",
            "comprovante_ref": "REC-0003",
        },
        headers=h,
    )
    assert r.status_code == 422


def test_rn06_data_futura_e_recusada(client, entrar):
    h = entrar("ana")
    amanha = (date.today() + timedelta(days=1)).isoformat()
    r = client.post(
        "/solicitacoes",
        json={
            "categoria": "hospedagem",
            "valor": 300,
            "data_despesa": amanha,
            "justificativa": "Hotel em viagem a cliente",
            "comprovante_ref": "REC-0004",
        },
        headers=h,
    )
    assert r.status_code == 422


def test_rn06_data_de_hoje_e_aceita(client, entrar, nova_solicitacao):
    h = entrar("ana")
    s = nova_solicitacao(h, data_despesa=date.today().isoformat())
    assert s["situacao"] == "rascunho"


def test_rn05_mesmo_comprovante_nao_pode_ser_reutilizado(client, entrar, nova_solicitacao):
    h = entrar("ana")
    nova_solicitacao(h, comprovante_ref="NF-DUPLICADA")
    r = client.post(
        "/solicitacoes",
        json={
            "categoria": "alimentacao",
            "valor": 99,
            "data_despesa": "2026-11-03",
            "justificativa": "Mesma nota enviada de novo",
            "comprovante_ref": "nf-duplicada",  # diferença só de maiúsculas
        },
        headers=h,
    )
    assert r.status_code == 409


def test_rn05_comprovante_igual_de_outro_colaborador_e_permitido(client, entrar, nova_solicitacao):
    nova_solicitacao(entrar("ana"), comprovante_ref="NF-COMUM")
    s = nova_solicitacao(entrar("bruno"), comprovante_ref="NF-COMUM")
    assert s["solicitante_nome"] == "Bruno Lima"


# ============================================================ Consulta, edição, exclusão (RN02, RN07)
def test_listar_minhas_solicitacoes_com_filtros(client, entrar, nova_solicitacao):
    h = entrar("ana")
    nova_solicitacao(h, categoria="alimentacao")
    transporte = nova_solicitacao(h, categoria="transporte")
    enviar_ate_o_gestor(client, h, transporte["id"])

    todas = client.get("/solicitacoes", headers=h).json()
    assert len(todas) == 2
    so_transporte = client.get("/solicitacoes?categoria=transporte", headers=h).json()
    assert [s["id"] for s in so_transporte] == [transporte["id"]]
    so_rascunho = client.get("/solicitacoes?situacao=rascunho", headers=h).json()
    assert len(so_rascunho) == 1 and so_rascunho[0]["categoria"] == "alimentacao"
    assert client.get("/solicitacoes?situacao=inexistente", headers=h).status_code == 422


def test_listagem_nunca_inclui_solicitacoes_de_outros(client, entrar, nova_solicitacao):
    nova_solicitacao(entrar("bruno"))
    assert client.get("/solicitacoes", headers=entrar("ana")).json() == []


def test_editar_rascunho_e_permitido(client, entrar, nova_solicitacao):
    h = entrar("ana")
    s = nova_solicitacao(h)
    r = client.patch(f"/solicitacoes/{s['id']}", json={"valor": 200.5, "justificativa": "Valor corrigido"}, headers=h)
    assert r.status_code == 200
    assert r.json()["valor"] == 200.5
    assert r.json()["justificativa"] == "Valor corrigido"


def test_editar_sem_nenhum_campo_ou_com_campo_nulo_e_recusado(client, entrar, nova_solicitacao):
    h = entrar("ana")
    s = nova_solicitacao(h)
    assert client.patch(f"/solicitacoes/{s['id']}", json={}, headers=h).status_code == 422
    assert client.patch(f"/solicitacoes/{s['id']}", json={"valor": None}, headers=h).status_code == 422


def test_editar_comprovante_para_um_ja_usado_e_recusado(client, entrar, nova_solicitacao):
    h = entrar("ana")
    a = nova_solicitacao(h, comprovante_ref="NF-A")
    b = nova_solicitacao(h, comprovante_ref="NF-B")
    r = client.patch(f"/solicitacoes/{b['id']}", json={"comprovante_ref": "NF-A"}, headers=h)
    assert r.status_code == 409
    # manter o próprio comprovante é permitido
    r = client.patch(f"/solicitacoes/{a['id']}", json={"comprovante_ref": "NF-A"}, headers=h)
    assert r.status_code == 200


def test_excluir_rascunho(client, entrar, nova_solicitacao):
    h = entrar("ana")
    s = nova_solicitacao(h)
    assert client.delete(f"/solicitacoes/{s['id']}", headers=h).status_code == 204
    assert client.get(f"/solicitacoes/{s['id']}", headers=h).status_code == 404


def test_nao_exclui_solicitacao_ja_enviada(client, entrar, nova_solicitacao):
    h = entrar("ana")
    s = nova_solicitacao(h)
    enviar_ate_o_gestor(client, h, s["id"])
    assert client.delete(f"/solicitacoes/{s['id']}", headers=h).status_code == 409
    assert client.get(f"/solicitacoes/{s['id']}", headers=h).status_code == 200


def test_enviar_duas_vezes_e_recusado(client, entrar, nova_solicitacao):
    h = entrar("ana")
    s = nova_solicitacao(h)
    enviar_ate_o_gestor(client, h, s["id"])
    assert client.post(f"/solicitacoes/{s['id']}/enviar", headers=h).status_code == 409


def test_nao_edita_nem_exclui_nem_envia_solicitacao_de_outro_colaborador(client, entrar, nova_solicitacao):
    s = nova_solicitacao(entrar("bruno"))
    h = entrar("ana")
    assert client.patch(f"/solicitacoes/{s['id']}", json={"valor": 1}, headers=h).status_code == 404
    assert client.delete(f"/solicitacoes/{s['id']}", headers=h).status_code == 404
    assert client.post(f"/solicitacoes/{s['id']}/enviar", headers=h).status_code == 404


# ====================================================================== CENÁRIOS (seção 7)
def test_cen01_acesso_indevido_ana_consulta_solicitacao_do_bruno(client, entrar, nova_solicitacao):
    bruno = entrar("bruno")
    s = nova_solicitacao(bruno, valor=180.00, justificativa="Despesa confidencial do Bruno", comprovante_ref="SEGREDO-77")
    enviar_ate_o_gestor(client, bruno, s["id"])

    ana = entrar("ana")
    for rota in (f"/solicitacoes/{s['id']}", f"/solicitacoes/{s['id']}/historico"):
        r = client.get(rota, headers=ana)
        assert r.status_code == 404
        texto = r.text
        assert "Bruno" not in texto and "180" not in texto and "confidencial" not in texto and "SEGREDO" not in texto
    # A resposta é idêntica à de um identificador que não existe: não revela que existe.
    inexistente = client.get("/solicitacoes/99999", headers=ana)
    assert client.get(f"/solicitacoes/{s['id']}", headers=ana).json() == inexistente.json()
    # Também não aparece em nenhuma listagem da Ana
    assert client.get("/solicitacoes", headers=ana).json() == []


def test_cen02_gestor_de_outro_departamento_nao_aprova(client, entrar, nova_solicitacao):
    bruno = entrar("bruno")
    s = nova_solicitacao(bruno)
    enviar_ate_o_gestor(client, bruno, s["id"])

    patricia = entrar("patricia")  # gestora do Comercial
    r = client.post(f"/gestor/solicitacoes/{s['id']}/aprovar", headers=patricia)
    assert r.status_code == 403
    r = client.post(
        f"/gestor/solicitacoes/{s['id']}/recusar", json={"justificativa": "Tentativa indevida"}, headers=patricia
    )
    assert r.status_code == 403

    # Nada mudou: segue aguardando o gestor de Tecnologia e sem histórico
    atual = client.get(f"/solicitacoes/{s['id']}", headers=bruno).json()
    assert atual["situacao"] == "aguardando_gestor"
    assert client.get(f"/solicitacoes/{s['id']}/historico", headers=bruno).json() == []

    # Ela também não consegue nem consultar os detalhes
    assert client.get(f"/solicitacoes/{s['id']}", headers=patricia).status_code == 404

    # O gestor correto (Tecnologia) consegue
    carlos = entrar("carlos")
    assert client.post(f"/gestor/solicitacoes/{s['id']}/aprovar", headers=carlos).status_code == 200


def test_cen05_financeiro_nao_aprova_antes_do_gestor(client, entrar, nova_solicitacao):
    ana = entrar("ana")
    s = nova_solicitacao(ana)
    enviar_ate_o_gestor(client, ana, s["id"])

    fernanda = entrar("fernanda")
    r = client.post(f"/financeiro/solicitacoes/{s['id']}/aprovar", headers=fernanda)
    assert r.status_code == 409
    r = client.post(f"/financeiro/solicitacoes/{s['id']}/pagamento", headers=fernanda)
    assert r.status_code == 409

    assert client.get(f"/solicitacoes/{s['id']}", headers=ana).json()["situacao"] == "aguardando_gestor"
    assert client.get(f"/solicitacoes/{s['id']}/historico", headers=ana).json() == []


def test_financeiro_nao_enxerga_nem_age_sobre_rascunho_de_terceiros(client, entrar, nova_solicitacao):
    s = nova_solicitacao(entrar("ana"))
    fernanda = entrar("fernanda")
    assert client.get(f"/solicitacoes/{s['id']}", headers=fernanda).status_code == 404
    assert client.post(f"/financeiro/solicitacoes/{s['id']}/aprovar", headers=fernanda).status_code == 404


def test_cen06_manipulacao_de_valor_apos_o_envio(client, entrar, nova_solicitacao):
    ana = entrar("ana")
    s = nova_solicitacao(ana, valor=180.00)
    enviar_ate_o_gestor(client, ana, s["id"])

    r = client.patch(f"/solicitacoes/{s['id']}", json={"valor": 1800.00}, headers=ana)
    assert r.status_code == 409

    atual = client.get(f"/solicitacoes/{s['id']}", headers=ana).json()
    assert atual["valor"] == 180.0
    assert atual["situacao"] == "aguardando_gestor"


def test_rn07_solicitacao_encerrada_nao_pode_ser_modificada(client, entrar, nova_solicitacao):
    ana, patricia, fernanda = entrar("ana"), entrar("patricia"), entrar("fernanda")
    s = nova_solicitacao(ana)
    enviar_ate_o_gestor(client, ana, s["id"])
    aprovar_pelo_gestor(client, patricia, s["id"])
    client.post(f"/financeiro/solicitacoes/{s['id']}/aprovar", headers=fernanda)
    client.post(f"/financeiro/solicitacoes/{s['id']}/pagamento", headers=fernanda)

    assert client.get(f"/solicitacoes/{s['id']}", headers=ana).json()["situacao"] == "paga"
    assert client.patch(f"/solicitacoes/{s['id']}", json={"valor": 1}, headers=ana).status_code == 409
    assert client.delete(f"/solicitacoes/{s['id']}", headers=ana).status_code == 409
    assert client.post(f"/solicitacoes/{s['id']}/enviar", headers=ana).status_code == 409
    # Processo encerrado: nenhuma ação adicional é aceita
    assert client.post(f"/financeiro/solicitacoes/{s['id']}/pagamento", headers=fernanda).status_code == 409
    assert client.post(f"/financeiro/solicitacoes/{s['id']}/aprovar", headers=fernanda).status_code == 409
    assert client.post(f"/gestor/solicitacoes/{s['id']}/aprovar", headers=patricia).status_code == 409


def test_cen07_gestor_consulta_pendentes_so_do_proprio_departamento(client, entrar, nova_solicitacao):
    ana, bruno = entrar("ana"), entrar("bruno")
    da_ana = nova_solicitacao(ana)
    do_bruno = nova_solicitacao(bruno)
    rascunho_da_ana = nova_solicitacao(ana)
    enviar_ate_o_gestor(client, ana, da_ana["id"])
    enviar_ate_o_gestor(client, bruno, do_bruno["id"])

    patricia = entrar("patricia")
    r = client.get("/gestor/solicitacoes?situacao=aguardando_gestor", headers=patricia)
    assert r.status_code == 200
    ids = [s["id"] for s in r.json()]
    assert ids == [da_ana["id"]]
    assert do_bruno["id"] not in ids
    assert rascunho_da_ana["id"] not in ids  # rascunhos não são vistos pelo gestor
    assert all(s["departamento_id"] == 1 for s in r.json())  # 1 = Comercial no seed
    assert "Bruno" not in r.text

    # Tentar filtrar por outro departamento é negado
    assert client.get("/gestor/solicitacoes?departamento_id=2", headers=patricia).status_code == 403
    # O filtro pelo próprio departamento funciona
    assert client.get("/gestor/solicitacoes?departamento_id=1", headers=patricia).status_code == 200

    # Filtros de categoria também respeitam o escopo
    assert client.get("/gestor/solicitacoes?categoria=transporte", headers=patricia).json() == []

    # Perfis sem permissão não usam esta consulta
    assert client.get("/gestor/solicitacoes", headers=ana).status_code == 403
    assert client.get("/gestor/solicitacoes", headers=entrar("fernanda")).status_code == 403


def test_cen08_historico_completo_do_fluxo(client, entrar, nova_solicitacao):
    ana, patricia, fernanda = entrar("ana"), entrar("patricia"), entrar("fernanda")
    s = nova_solicitacao(ana, valor=180.00)
    enviar_ate_o_gestor(client, ana, s["id"])

    r = aprovar_pelo_gestor(client, patricia, s["id"])
    assert r["situacao"] == "aguardando_financeiro"

    r = client.post(f"/financeiro/solicitacoes/{s['id']}/aprovar", json={"observacao": "Valores conferidos"}, headers=fernanda)
    assert r.status_code == 200 and r.json()["situacao"] == "aprovada"

    r = client.post(f"/financeiro/solicitacoes/{s['id']}/pagamento", json={"observacao": "Pago via PIX"}, headers=fernanda)
    assert r.status_code == 200 and r.json()["situacao"] == "paga"

    # O colaborador, o gestor e o financeiro conseguem recuperar o histórico completo
    for quem in (ana, patricia, fernanda):
        r = client.get(f"/solicitacoes/{s['id']}/historico", headers=quem)
        assert r.status_code == 200
        h = r.json()
        assert [(e["etapa"], e["decisao"]) for e in h] == [
            ("gestor", "aprovada"),
            ("financeiro", "aprovada"),
            ("pagamento", "paga"),
        ]
        assert [e["responsavel_nome"] for e in h] == ["Patrícia Alves", "Fernanda Rocha", "Fernanda Rocha"]
        assert [e["responsavel_perfil"] for e in h] == ["gestor", "financeiro", "financeiro"]
        assert all(e["data"] for e in h)
        assert h[1]["observacao"] == "Valores conferidos"
        assert h[2]["observacao"] == "Pago via PIX"


# ===================================================================== regras de aprovação
def test_rn08_pagamento_so_apos_aprovacao_financeira(client, entrar, nova_solicitacao):
    ana, patricia, fernanda = entrar("ana"), entrar("patricia"), entrar("fernanda")
    s = nova_solicitacao(ana)
    enviar_ate_o_gestor(client, ana, s["id"])
    aprovar_pelo_gestor(client, patricia, s["id"])
    # Já passou pelo gestor, mas ainda não foi aprovada pelo financeiro
    r = client.post(f"/financeiro/solicitacoes/{s['id']}/pagamento", headers=fernanda)
    assert r.status_code == 409  # RN10
    assert client.get(f"/solicitacoes/{s['id']}", headers=ana).json()["situacao"] == "aguardando_financeiro"


def test_rn09_gestor_nao_aprova_a_propria_solicitacao(client, entrar, nova_solicitacao):
    patricia = entrar("patricia")
    s = nova_solicitacao(patricia)
    enviar_ate_o_gestor(client, patricia, s["id"])
    r = client.post(f"/gestor/solicitacoes/{s['id']}/aprovar", headers=patricia)
    assert r.status_code == 403
    r = client.post(
        f"/gestor/solicitacoes/{s['id']}/recusar", json={"justificativa": "Recusa da própria"}, headers=patricia
    )
    assert r.status_code == 403
    assert client.get(f"/solicitacoes/{s['id']}", headers=patricia).json()["situacao"] == "aguardando_gestor"
    assert client.get(f"/solicitacoes/{s['id']}/historico", headers=patricia).json() == []


def test_rn09_financeiro_nao_aprova_nem_paga_a_propria_solicitacao(client, entrar, nova_solicitacao):
    """Leva uma solicitação da Fernanda até 'aguardando_financeiro' alterando o banco diretamente,
    para provar que a segregação (RN09) vale mesmo com a situação correta."""
    from app.database import SessionLocal
    from app.models import Solicitacao
    from app.regras import Situacao

    fernanda = entrar("fernanda")
    s = nova_solicitacao(fernanda)
    with SessionLocal() as db:
        db.get(Solicitacao, s["id"]).situacao = Situacao.AGUARDANDO_FINANCEIRO
        db.commit()
    assert client.post(f"/financeiro/solicitacoes/{s['id']}/aprovar", headers=fernanda).status_code == 403
    with SessionLocal() as db:
        db.get(Solicitacao, s["id"]).situacao = Situacao.APROVADA
        db.commit()
    assert client.post(f"/financeiro/solicitacoes/{s['id']}/pagamento", headers=fernanda).status_code == 403


def test_rn11_recusa_exige_justificativa_registrada_no_historico(client, entrar, nova_solicitacao):
    ana, patricia = entrar("ana"), entrar("patricia")
    s = nova_solicitacao(ana)
    enviar_ate_o_gestor(client, ana, s["id"])

    # sem justificativa: dados inválidos, e a solicitação não muda
    assert client.post(f"/gestor/solicitacoes/{s['id']}/recusar", json={}, headers=patricia).status_code == 422
    assert client.post(f"/gestor/solicitacoes/{s['id']}/recusar", headers=patricia).status_code == 422
    assert client.post(f"/gestor/solicitacoes/{s['id']}/recusar", json={"justificativa": "  "}, headers=patricia).status_code == 422
    assert client.get(f"/solicitacoes/{s['id']}", headers=ana).json()["situacao"] == "aguardando_gestor"

    r = client.post(
        f"/gestor/solicitacoes/{s['id']}/recusar", json={"justificativa": "Comprovante ilegível"}, headers=patricia
    )
    assert r.status_code == 200 and r.json()["situacao"] == "recusada"
    historico = client.get(f"/solicitacoes/{s['id']}/historico", headers=ana).json()
    assert len(historico) == 1
    assert historico[0]["decisao"] == "recusada"
    assert historico[0]["observacao"] == "Comprovante ilegível"
    assert historico[0]["responsavel_nome"] == "Patrícia Alves"

    # encerrada: ninguém mais decide
    assert client.post(f"/gestor/solicitacoes/{s['id']}/aprovar", headers=patricia).status_code == 409


def test_financeiro_recusa_e_enxerga_a_recusada(client, entrar, nova_solicitacao):
    ana, patricia, fernanda = entrar("ana"), entrar("patricia"), entrar("fernanda")
    s = nova_solicitacao(ana)
    enviar_ate_o_gestor(client, ana, s["id"])
    aprovar_pelo_gestor(client, patricia, s["id"])
    r = client.post(f"/financeiro/solicitacoes/{s['id']}/recusar", json={"justificativa": "Valor acima da política"}, headers=fernanda)
    assert r.status_code == 200 and r.json()["situacao"] == "recusada"
    ids = [x["id"] for x in client.get("/financeiro/solicitacoes?situacao=recusada", headers=fernanda).json()]
    assert ids == [s["id"]]


def test_financeiro_so_ve_o_que_passou_pelo_gestor_e_filtra_por_departamento(client, entrar, nova_solicitacao):
    ana, bruno = entrar("ana"), entrar("bruno")
    patricia, carlos, fernanda = entrar("patricia"), entrar("carlos"), entrar("fernanda")
    a = nova_solicitacao(ana, categoria="alimentacao")
    b = nova_solicitacao(bruno, categoria="transporte")
    ainda_no_gestor = nova_solicitacao(ana)
    enviar_ate_o_gestor(client, ana, a["id"])
    enviar_ate_o_gestor(client, bruno, b["id"])
    enviar_ate_o_gestor(client, ana, ainda_no_gestor["id"])
    aprovar_pelo_gestor(client, patricia, a["id"])
    aprovar_pelo_gestor(client, carlos, b["id"])

    todas = client.get("/financeiro/solicitacoes", headers=fernanda).json()
    assert sorted(s["id"] for s in todas) == sorted([a["id"], b["id"]])
    assert ainda_no_gestor["id"] not in [s["id"] for s in todas]

    so_tecnologia = client.get("/financeiro/solicitacoes?departamento_id=2", headers=fernanda).json()
    assert [s["id"] for s in so_tecnologia] == [b["id"]]
    so_transporte = client.get("/financeiro/solicitacoes?categoria=transporte", headers=fernanda).json()
    assert [s["id"] for s in so_transporte] == [b["id"]]
    pendentes = client.get("/financeiro/solicitacoes?situacao=aguardando_financeiro", headers=fernanda).json()
    assert len(pendentes) == 2

    # Colaborador e gestor não usam a consulta do financeiro
    assert client.get("/financeiro/solicitacoes", headers=ana).status_code == 403
    assert client.get("/financeiro/solicitacoes", headers=patricia).status_code == 403


def test_gestor_pode_ver_detalhe_e_historico_do_proprio_departamento(client, entrar, nova_solicitacao):
    ana, patricia = entrar("ana"), entrar("patricia")
    s = nova_solicitacao(ana)
    # rascunho ainda é privado
    assert client.get(f"/solicitacoes/{s['id']}", headers=patricia).status_code == 404
    enviar_ate_o_gestor(client, ana, s["id"])
    assert client.get(f"/solicitacoes/{s['id']}", headers=patricia).status_code == 200
    assert client.get(f"/solicitacoes/{s['id']}/historico", headers=patricia).status_code == 200


def test_colaborador_nao_acessa_rotas_de_analise(client, entrar, nova_solicitacao):
    ana = entrar("ana")
    s = nova_solicitacao(ana)
    assert client.post(f"/gestor/solicitacoes/{s['id']}/aprovar", headers=ana).status_code == 403
    assert client.post(f"/financeiro/solicitacoes/{s['id']}/aprovar", headers=ana).status_code == 403
    assert client.post(f"/financeiro/solicitacoes/{s['id']}/pagamento", headers=ana).status_code == 403


def test_documentacao_da_api_esta_disponivel(client):
    assert client.get("/docs").status_code == 200
    assert client.get("/openapi.json").status_code == 200
    assert client.get("/saude").json() == {"status": "ok"}
