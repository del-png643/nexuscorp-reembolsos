"""Configuração dos testes de API: banco SQLite próprio, recriado do zero a cada teste."""
import os

# Precisa vir ANTES de importar a aplicação.
os.environ["DATABASE_URL"] = "sqlite:///./test_nexuscorp.db"
os.environ["SECRET_KEY"] = "chave-somente-para-testes"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.database import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from app.seed import SENHA_DEMO, popular_dados_demo  # noqa: E402


@pytest.fixture(autouse=True)
def banco_limpo():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        popular_dados_demo(db)
    yield


@pytest.fixture
def client():
    return TestClient(app)


@pytest.fixture
def entrar(client):
    """Devolve uma função que faz login e entrega o cabeçalho Authorization."""

    def _entrar(usuario: str, senha: str = SENHA_DEMO) -> dict:
        resposta = client.post("/auth/login", json={"email": f"{usuario}@nexuscorp.com.br", "senha": senha})
        assert resposta.status_code == 200, resposta.text
        return {"Authorization": f"Bearer {resposta.json()['access_token']}"}

    return _entrar


@pytest.fixture
def nova_solicitacao(client):
    """Cria um rascunho e devolve o JSON da solicitação."""
    contador = {"n": 0}

    def _criar(headers: dict, **alteracoes) -> dict:
        contador["n"] += 1
        corpo = {
            "categoria": "alimentacao",
            "valor": 180.00,
            "data_despesa": "2026-11-03",
            "justificativa": "Almoço com cliente em visita técnica",
            "comprovante_ref": f"NF-{contador['n']:05d}",
        }
        corpo.update(alteracoes)
        resposta = client.post("/solicitacoes", json=corpo, headers=headers)
        assert resposta.status_code == 201, resposta.text
        return resposta.json()

    return _criar
