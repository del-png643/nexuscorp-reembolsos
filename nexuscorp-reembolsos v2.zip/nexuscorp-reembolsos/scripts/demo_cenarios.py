"""Demonstração dos 8 cenários de homologação contra a API em execução.

Uso (com a API rodando e os dados de demonstração criados):
    python scripts/demo_cenarios.py                # usa http://127.0.0.1:8000
    python scripts/demo_cenarios.py http://host:porta

Gera um relatório legível no terminal. Para guardar como evidência:
    python scripts/demo_cenarios.py > docs/evidencias/demo_cenarios.txt
"""
import json
import sys
import time

import httpx

BASE = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://127.0.0.1:8000"
SENHA = "Senha@123"
SUFIXO = str(int(time.time()))  # evita conflito de comprovante em execuções repetidas
cliente = httpx.Client(base_url=BASE, timeout=15)
falhas = []


def titulo(texto: str) -> None:
    print(f"\n{'=' * 78}\n{texto}\n{'=' * 78}")


def chamar(metodo: str, caminho: str, headers=None, **kwargs) -> httpx.Response:
    return cliente.request(metodo, caminho, headers=headers, **kwargs)


def conferir(descricao: str, resposta: httpx.Response, esperado: int) -> httpx.Response:
    ok = resposta.status_code == esperado
    if not ok:
        falhas.append(descricao)
    marca = "OK " if ok else "ERRO"
    print(f"  [{marca}] {descricao}\n         -> HTTP {resposta.status_code} (esperado {esperado})")
    if resposta.content:
        corpo = resposta.text if len(resposta.text) < 300 else resposta.text[:300] + "..."
        print(f"         corpo: {corpo}")
    return resposta


def entrar(usuario: str) -> dict:
    r = chamar("POST", "/auth/login", json={"email": f"{usuario}@nexuscorp.com.br", "senha": SENHA})
    if r.status_code != 200:
        sys.exit(f"Não foi possível entrar como {usuario} ({r.status_code}). A API está no ar e o seed foi executado?")
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def criar(headers: dict, rotulo: str, valor: float = 180.0) -> dict:
    r = chamar(
        "POST",
        "/solicitacoes",
        headers=headers,
        json={
            "categoria": "alimentacao",
            "valor": valor,
            "data_despesa": "2026-11-03",
            "justificativa": f"Despesa de demonstração ({rotulo})",
            "comprovante_ref": f"DEMO-{rotulo}-{SUFIXO}",
        },
    )
    assert r.status_code == 201, r.text
    return r.json()


def enviar(headers: dict, solicitacao_id: int) -> None:
    r = chamar("POST", f"/solicitacoes/{solicitacao_id}/enviar", headers=headers)
    assert r.status_code == 200, r.text


def main() -> None:
    print(f"API: {BASE}")
    ana, bruno = entrar("ana"), entrar("bruno")
    patricia, carlos, fernanda = entrar("patricia"), entrar("carlos"), entrar("fernanda")

    titulo("Cenário 01 — Acesso indevido (Ana tenta ler a solicitação do Bruno)")
    s = criar(bruno, "cen01")
    enviar(bruno, s["id"])
    print(f"  Bruno (Tecnologia) registrou a solicitação #{s['id']} de R$ 180,00")
    conferir(f"Ana (Comercial) consulta GET /solicitacoes/{s['id']}", chamar("GET", f"/solicitacoes/{s['id']}", ana), 404)
    conferir(f"Ana consulta GET /solicitacoes/{s['id']}/historico", chamar("GET", f"/solicitacoes/{s['id']}/historico", ana), 404)

    titulo("Cenário 02 — Gestor de outro departamento (Patrícia tenta aprovar despesa de Tecnologia)")
    conferir(
        f"Patrícia (gestora do Comercial) aprova a solicitação #{s['id']} do Bruno",
        chamar("POST", f"/gestor/solicitacoes/{s['id']}/aprovar", patricia),
        403,
    )
    atual = chamar("GET", f"/solicitacoes/{s['id']}", bruno).json()
    print(f"  Situação continua: {atual['situacao']}")

    titulo("Cenário 03 — Credenciais incorretas")
    conferir(
        "Login da Ana com senha incorreta",
        chamar("POST", "/auth/login", json={"email": "ana@nexuscorp.com.br", "senha": "SenhaErrada9"}),
        401,
    )
    conferir(
        "Login com e-mail inexistente (mesma resposta, não revela quais e-mails existem)",
        chamar("POST", "/auth/login", json={"email": "ninguem@nexuscorp.com.br", "senha": "SenhaErrada9"}),
        401,
    )

    titulo("Cenário 04 — Tentativa de alteração de permissões")
    conferir(
        "Ana tenta PATCH /usuarios/me com {'perfil': 'financeiro'}",
        chamar("PATCH", "/usuarios/me", ana, json={"perfil": "financeiro"}),
        422,
    )
    conferir(
        "Ana tenta PATCH /usuarios/me com {'departamento_id': 3} (Financeiro)",
        chamar("PATCH", "/usuarios/me", ana, json={"departamento_id": 3}),
        422,
    )
    conferir(
        "Cadastro de novo usuário tentando definir perfil financeiro",
        chamar(
            "POST",
            "/usuarios",
            json={
                "nome": "Mallory Teste",
                "email": f"mallory{SUFIXO}@nexuscorp.com.br",
                "senha": "Senha@123",
                "departamento_id": 3,
                "perfil": "financeiro",
            },
        ),
        422,
    )
    eu = chamar("GET", "/usuarios/me", ana).json()
    print(f"  Perfil da Ana continua: {eu['perfil']} / {eu['departamento']['nome']}")
    conferir("Ana tenta usar a consulta do financeiro", chamar("GET", "/financeiro/solicitacoes", ana), 403)

    titulo("Cenário 05 — Aprovação fora da sequência (financeiro antes do gestor)")
    s5 = criar(ana, "cen05")
    enviar(ana, s5["id"])
    conferir(
        f"Fernanda (financeiro) aprova a solicitação #{s5['id']} que aguarda o gestor",
        chamar("POST", f"/financeiro/solicitacoes/{s5['id']}/aprovar", fernanda),
        409,
    )

    titulo("Cenário 06 — Manipulação de solicitação após o envio (R$ 180,00 -> R$ 1.800,00)")
    s6 = criar(ana, "cen06", valor=180.0)
    enviar(ana, s6["id"])
    conferir(
        f"Ana altera o valor da solicitação #{s6['id']} já enviada",
        chamar("PATCH", f"/solicitacoes/{s6['id']}", ana, json={"valor": 1800.0}),
        409,
    )
    atual = chamar("GET", f"/solicitacoes/{s6['id']}", ana).json()
    print(f"  Valor preservado: R$ {atual['valor']:.2f} | situação: {atual['situacao']}")

    titulo("Cenário 07 — Consulta com filtros (gestor só vê o próprio departamento)")
    r = conferir(
        "Patrícia consulta GET /gestor/solicitacoes?situacao=aguardando_gestor",
        chamar("GET", "/gestor/solicitacoes?situacao=aguardando_gestor", patricia),
        200,
    )
    departamentos = {item["departamento_id"] for item in r.json()}
    print(f"  Departamentos presentes na resposta: {sorted(departamentos)} (esperado: apenas [1] = Comercial)")
    if departamentos - {1}:
        falhas.append("Cenário 07: resposta inclui outro departamento")
    conferir(
        "Patrícia tenta filtrar por outro departamento (?departamento_id=2)",
        chamar("GET", "/gestor/solicitacoes?departamento_id=2", patricia),
        403,
    )

    titulo("Cenário 08 — Histórico financeiro (gestor -> financeiro -> pagamento)")
    s8 = criar(ana, "cen08")
    enviar(ana, s8["id"])
    conferir("Patrícia (gestora) aprova", chamar("POST", f"/gestor/solicitacoes/{s8['id']}/aprovar", patricia, json={"observacao": "Despesa regular"}), 200)
    conferir("Fernanda (financeiro) aprova", chamar("POST", f"/financeiro/solicitacoes/{s8['id']}/aprovar", fernanda, json={"observacao": "Valores conferidos"}), 200)
    conferir("Fernanda registra o pagamento", chamar("POST", f"/financeiro/solicitacoes/{s8['id']}/pagamento", fernanda, json={"observacao": "Pago via PIX"}), 200)
    r = conferir("Ana consulta o histórico completo", chamar("GET", f"/solicitacoes/{s8['id']}/historico", ana), 200)
    print("\n  Histórico recuperado:")
    for item in r.json():
        print(
            f"   - {item['data']} | {item['etapa']:<10} | {item['decisao']:<8} | "
            f"{item['responsavel_nome']} ({item['responsavel_perfil']}) | {item['observacao']}"
        )
    situacao = chamar("GET", f"/solicitacoes/{s8['id']}", ana).json()["situacao"]
    print(f"\n  Situação final: {situacao}")
    if situacao != "paga" or len(r.json()) != 3:
        falhas.append("Cenário 08: fluxo incompleto")

    titulo("Resumo")
    if falhas:
        print(f"{len(falhas)} verificação(ões) com resultado diferente do esperado:")
        for falha in falhas:
            print(f"  - {falha}")
        sys.exit(1)
    print("Todas as verificações obtiveram o resultado esperado.")


if __name__ == "__main__":
    main()
